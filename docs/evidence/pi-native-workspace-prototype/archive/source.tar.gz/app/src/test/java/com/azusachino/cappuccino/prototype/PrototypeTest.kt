package com.azusachino.cappuccino.prototype

import com.azusachino.cappuccino.prototype.fixture.PiFixtures
import com.azusachino.cappuccino.prototype.logic.FollowPolicy
import com.azusachino.cappuccino.prototype.logic.PassivePolicy
import com.azusachino.cappuccino.prototype.logic.StreamPlayer
import com.azusachino.cappuccino.prototype.logic.StreamReducer
import com.azusachino.cappuccino.prototype.logic.WorkspaceState
import com.azusachino.cappuccino.prototype.model.AgentStatus
import com.azusachino.cappuccino.prototype.model.CompletionTruth
import com.azusachino.cappuccino.prototype.model.Connectivity
import com.azusachino.cappuccino.prototype.model.Part
import com.azusachino.cappuccino.prototype.model.Role
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** JVM tests for the Step B prototype fixture logic. No Android runtime involved. */
class PrototypeTest {

  // --- fixture mapping ---

  @Test
  fun `roster groups machines with agent rows carrying identity job session status`() {
    assertEquals(2, PiFixtures.roster.size)
    PiFixtures.roster.forEach { group ->
      assertTrue(group.agents.isNotEmpty())
      group.agents.forEach { row ->
        assertTrue(row.identity.machine == group.machine)
        assertTrue(row.identity.job.isNotBlank())
        assertTrue(row.identity.sessionId.startsWith("sess-fixture-"))
      }
    }
  }

  @Test
  fun `conversation is ordered user assistant turns with parts inside owning turn`() {
    val turns = PiFixtures.conversationFor(PiFixtures.defaultSelection)
    assertEquals(Role.USER, turns[0].role)
    assertEquals(Role.ASSISTANT, turns[1].role)
    assertTrue(turns[1].parts.any { it is Part.Thinking })
    assertTrue(turns[1].parts.any { it is Part.ToolCall })
  }

  @Test
  fun `redacted thinking never exposes content beyond the label`() {
    val turns = PiFixtures.conversationFor(PiFixtures.defaultSelection)
    val redacted = turns[1].parts.filterIsInstance<Part.Thinking>().first { it.redacted }
    assertEquals("[redacted thinking content]", PassivePolicy.redactedThoughtLabel(redacted))
    // A plain thought passes through unchanged; the redacted one collapses to the label only.
    val plain = turns[1].parts.filterIsInstance<Part.Thinking>().first { !it.redacted }
    assertEquals(plain.content, PassivePolicy.redactedThoughtLabel(plain))
  }

  @Test
  fun `tool parts keep input and output and error flag`() {
    val tool =
      PiFixtures.conversationFor(PiFixtures.defaultSelection)[3]
        .parts
        .filterIsInstance<Part.ToolCall>()
        .first()
    assertTrue(tool.isError)
    assertTrue(tool.input.isNotBlank())
    assertTrue(tool.output.isNotBlank())
  }

  // --- streaming: delta + authoritative replacement ---

  @Test
  fun `deltas append in order`() {
    var r = StreamReducer()
    PiFixtures.Stream.deltas.forEach { d -> r = r.applyDelta(d) }
    assertEquals(PiFixtures.Stream.deltas.joinToString(""), r.content)
  }

  @Test
  fun `authoritative replacement replaces accumulated deltas`() {
    val r = StreamReducer.replayFixture()
    assertEquals(PiFixtures.Stream.authoritative, r.content)
    assertFalse(r.content.contains("**in chunks**"))
  }

  // --- status truth ---

  @Test
  fun `only settled status claims settled truth`() {
    assertTrue(WorkspaceState.initial().isSettledTruth(PiFixtures.roster[0].agents[0]))
    assertFalse(WorkspaceState.initial().isSettledTruth(PiFixtures.roster[0].agents[1]))
    WorkspaceState.nonSettledStatuses.forEach { s ->
      assertTrue(s.truth == CompletionTruth.HEURISTIC)
    }
  }

  @Test
  fun `unknown selection fails closed with null row and no label`() {
    val state = WorkspaceState.initial()
    assertNull(state.selectedRow(emptyList()))
    assertNull(state.headerStatusLabel(null))
  }

  // --- selection ---

  @Test
  fun `selection matches workspace identity to roster row`() {
    val target = PiFixtures.roster[1].agents[0].identity
    val state = WorkspaceState.initial().select(target)
    assertEquals(target, state.selectedRow(PiFixtures.roster)?.identity)
  }

  // --- unavailable actions ---

  @Test
  fun `every unavailable action carries a reason and none are queue abort or receipts enabled`() {
    assertTrue(PiFixtures.unavailableActions.isNotEmpty())
    PiFixtures.unavailableActions.forEach { a -> assertTrue(a.reason.isNotBlank()) }
  }

  // --- disconnected composer ---

  @Test
  fun `composer enabled only when connected, explicit placeholders otherwise`() {
    val state = WorkspaceState.initial()
    assertTrue(state.composerEnabled(Connectivity.CONNECTED))
    assertFalse(state.composerEnabled(Connectivity.READONLY))
    assertFalse(state.composerEnabled(Connectivity.DISCONNECTED))
    assertTrue(state.composerPlaceholder(Connectivity.DISCONNECTED).contains("disabled"))
    assertTrue(state.composerPlaceholder(Connectivity.READONLY).contains("disabled"))
  }

  // --- passive policy ---

  @Test
  fun `images map to passive text and policy flags stay closed`() {
    assertEquals(
      "[image: fixture alt]",
      PassivePolicy.passiveImageText("fixture alt", "https://example.invalid/x.png"),
    )
    assertEquals(
      "[image: https://example.invalid/x.png]",
      PassivePolicy.passiveImageText(null, "https://example.invalid/x.png"),
    )
    assertEquals("[image]", PassivePolicy.passiveImageText(null, null))
    assertTrue(PassivePolicy.LINK_NAVIGATION_DISABLED)
    assertTrue(PassivePolicy.IMAGES_RENDERED_AS_TEXT)
    assertTrue(PassivePolicy.NO_REMOTE_FETCH)
  }

  @Test
  fun `fixture conversation markdown contains link and image syntax that the passive path must neutralize`() {
    val markdown =
      PiFixtures.conversationFor(PiFixtures.defaultSelection)
        .flatMap { it.parts }
        .filterIsInstance<Part.Text>()
        .joinToString("\n") { it.markdown }
    assertTrue(markdown.contains("](https://"))
    assertTrue(markdown.contains(".png"))
  }

  // --- fixture statuses are never silently presented as settled ---

  @Test
  fun `manifest grants no INTERNET permission`() {
    val manifest = java.io.File("src/main/AndroidManifest.xml").readText()
    assertFalse(manifest.contains("android.permission.INTERNET"))
  }

  @Test
  fun `heuristic statuses are labelled as heuristic in their label`() {
    assertEquals("likely running (heuristic)", AgentStatus.LIKELY_RUNNING.label)
    assertEquals("disconnected", AgentStatus.DISCONNECTED.label)
  }
}

// --- F-01 regression coverage: structured nodes carry links that must stay passive ---

class StructuredPassivityTest {
  private val structured = PiFixtures.structuredMarkdown()

  @Test
  fun `fixture covers heading list nested quote and table link nodes`() {
    assertTrue(structured.contains("## Fixture [heading link](https://example.invalid/heading)"))
    assertTrue(structured.contains("- item one with a [list link](https://example.invalid/list)"))
    assertTrue(structured.contains("- nested [nested link](https://example.invalid/nested)"))
    assertTrue(
      structured.contains("> quoted text with a [quote link](https://example.invalid/quote)")
    )
    assertTrue(structured.contains("| [table link](https://example.invalid/table) | plain cell |"))
  }

  @Test
  fun `global passivity policy stays closed and image text mapping unchanged`() {
    assertTrue(PassivePolicy.LINK_NAVIGATION_DISABLED)
    assertTrue(PassivePolicy.IMAGES_RENDERED_AS_TEXT)
    assertTrue(PassivePolicy.NO_REMOTE_FETCH)
    assertEquals(
      "[image: alt]",
      PassivePolicy.passiveImageText("alt", "https://example.invalid/i.png"),
    )
  }
}

// --- F-06 regression coverage: StreamPlayer drives delta + authoritative replacement ---

class StreamPlayerTest {
  @Test
  fun `delta steps append chunks within generation zero`() {
    var p = StreamPlayer()
    repeat(PiFixtures.Stream.deltas.size) {
      assertFalse(p.finished)
      p = p.next()
      assertEquals(0, p.generation)
    }
    assertEquals(PiFixtures.Stream.deltas, p.chunks)
  }

  @Test
  fun `authoritative step resets generation and seeds full replacement`() {
    var p = StreamPlayer()
    repeat(PiFixtures.Stream.deltas.size) { p = p.next() }
    p = p.next()
    assertEquals(1, p.generation)
    assertEquals(listOf(PiFixtures.Stream.authoritative), p.chunks)
    assertTrue(p.finished)
    assertEquals(listOf(PiFixtures.Stream.authoritative), p.seedChunks(1))
    assertEquals(emptyList<String>(), p.seedChunks(0))
  }

  @Test
  fun `chunk rebuild equals reducer model`() {
    var p = StreamPlayer()
    repeat(p.totalSteps) { p = p.next() }
    assertEquals(p.reducer.content, p.chunks.joinToString(""))
    assertEquals(PiFixtures.Stream.authoritative, p.reducer.content)
  }

  @Test
  fun `reset returns to generation zero empty`() {
    var p = StreamPlayer()
    repeat(2) { p = p.next() }
    p = p.reset()
    assertEquals(StreamPlayer(), p)
    assertTrue(p.chunks.isEmpty())
  }

  @Test
  fun `next past end is a no-op`() {
    var p = StreamPlayer()
    repeat(p.totalSteps) { p = p.next() }
    val same = p.next()
    assertEquals(p, same)
  }
}

// --- F-03/F-04/F-05 shared-logic coverage: composer mutability + full action list ---

class ComposerAndActionsTest {
  @Test
  fun `composer logic allows editing only when connected`() {
    val state = WorkspaceState.initial()
    assertTrue(state.composerEnabled(Connectivity.CONNECTED))
    assertFalse(state.composerEnabled(Connectivity.READONLY))
    assertFalse(state.composerEnabled(Connectivity.DISCONNECTED))
  }

  @Test
  fun `all five unavailable actions are present with distinct reasons`() {
    assertEquals(5, PiFixtures.unavailableActions.size)
    assertEquals(5, PiFixtures.unavailableActions.map { it.reason }.toSet().size)
  }
}

// --- N-02 regression coverage: actual-tail geometry + user-intent follow policy ---

class FollowPolicyTest {
  private val viewportEnd = 800

  @Test
  fun `partial large last item extending past viewport is not tail`() {
    assertFalse(FollowPolicy.isAtActualTail(9, 1000, viewportEnd, 10))
  }

  @Test
  fun `penultimate item near tail is not tail`() {
    assertFalse(FollowPolicy.isAtActualTail(8, 790, viewportEnd, 10))
  }

  @Test
  fun `actual tail with reasonable pixel rounding is tail`() {
    assertTrue(FollowPolicy.isAtActualTail(9, 800, viewportEnd, 10))
    assertTrue(FollowPolicy.isAtActualTail(9, 801, viewportEnd, 10)) // within epsilon 2
    assertFalse(FollowPolicy.isAtActualTail(9, 804, viewportEnd, 10)) // beyond epsilon
  }

  @Test
  fun `empty and degenerate inputs are safely false`() {
    assertFalse(FollowPolicy.isAtActualTail(null, null, null, 0))
    assertFalse(FollowPolicy.isAtActualTail(null, 800, viewportEnd, 10))
    assertFalse(FollowPolicy.isAtActualTail(0, 0, viewportEnd, 0))
  }

  @Test
  fun `failing-old trace start-at-tail drag-away stop append does not auto-jump`() {
    // Start at the actual tail: following (idle at tail resumes/keeps true).
    assertEquals(
      true,
      FollowPolicy.followTransition(atTail = true, userActiveDrag = false, programmatic = false),
    )
    // User drags AWAY (actively scrolling, off the tail) — disarmed even though the
    // gesture started at the tail. This is the exact trace the old source got wrong.
    assertEquals(
      false,
      FollowPolicy.followTransition(atTail = false, userActiveDrag = true, programmatic = false),
    )
    // User stops reading (idle away): no write, intent stays false...
    assertNull(
      FollowPolicy.followTransition(atTail = false, userActiveDrag = false, programmatic = false)
    )
    // ...so the next streaming append (step effect requires followLatest) does NOT auto-jump.
  }

  @Test
  fun `programmatic movement never flips intent in either direction`() {
    assertNull(
      FollowPolicy.followTransition(atTail = true, userActiveDrag = false, programmatic = true)
    )
    assertNull(
      FollowPolicy.followTransition(atTail = false, userActiveDrag = true, programmatic = true)
    )
  }

  @Test
  fun `explicit jump resumes following and idle at actual tail resumes`() {
    // The jump button sets followLatest = true and scrolls programmatically; the
    // collector must not fight it and must keep it once idle at the tail.
    assertEquals(
      true,
      FollowPolicy.followTransition(atTail = true, userActiveDrag = false, programmatic = true)
        ?: true,
    )
    assertEquals(
      true,
      FollowPolicy.followTransition(atTail = true, userActiveDrag = false, programmatic = false),
    )
  }

  @Test
  fun `growth while following away from tail preserves intent`() {
    assertNull(
      FollowPolicy.followTransition(atTail = false, userActiveDrag = false, programmatic = false)
    )
  }
}
