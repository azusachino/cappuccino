package com.azusachino.cappuccino.prototype

import android.app.Instrumentation
import android.content.Intent
import android.content.IntentFilter
import android.view.WindowInsets
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.platform.UriHandler
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.semantics.getOrNull
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.click
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.isSelected
import androidx.compose.ui.test.junit4.v2.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeDown
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.azusachino.cappuccino.prototype.fixture.PiFixtures
import com.azusachino.cappuccino.prototype.ui.StreamGrowthObserver
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.FixMethodOrder
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.MethodSorters

/**
 * Step C instrumented fixture journeys on the owner-approved task AVD ONLY
 * (cappuccino-pi-workspace-preview-api35, serial emulator-5560). Synthetic fixtures only; every
 * assertion is a single interaction with explicit preconditions — no retries, no sleeps, no
 * conditional double-clicks, no weakened assertions.
 */
@RunWith(AndroidJUnit4::class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
class StepCJourneyTest {

  @get:Rule val compose = createAndroidComposeRule<PrototypeActivity>()

  private val profile: String =
    InstrumentationRegistry.getArguments().getString("profile") ?: "short"

  private val theme: String = InstrumentationRegistry.getArguments().getString("theme") ?: "light"

  /**
   * Original-pixel PNG capture via UiAutomation.takeScreenshot into the runner's
   * PlatformTestStorage (survives Gradle teardown; surfaces in
   * connected_android_test_additional_output). Profile/theme in the filename prevents overwrite
   * across runs. No crop/resize/composite.
   */
  private fun capture(name: String) {
    val bitmap =
      requireNotNull(InstrumentationRegistry.getInstrumentation().uiAutomation.takeScreenshot())
    try {
      androidx.test.platform.io.PlatformTestStorageRegistry.getInstance()
        .openOutputFile("stepc-$profile-$theme-$name.png")
        .use { assertTrue(bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)) }
    } finally {
      bitmap.recycle()
    }
  }

  private fun scrollToText(text: String) {
    compose.onNodeWithTag("workspace-list").performScrollToNode(hasText(text, substring = true))
  }

  /** The prototype boots into the workspace with the default fixture selection. */
  private fun gotoRoster() {
    compose.onNodeWithContentDescription("Back to roster").performClick()
  }

  /** Registers an ACTION_VIEW monitor; `hits` must stay 0 — passive URI proof. */
  private fun newUriMonitor(): Instrumentation.ActivityMonitor {
    val monitor = Instrumentation.ActivityMonitor(IntentFilter(Intent.ACTION_VIEW), null, true)
    InstrumentationRegistry.getInstrumentation().addMonitor(monitor)
    return monitor
  }

  /**
   * OUTER recording URI handler (test-only). Installed through the ACTIVITY's instance snapshot
   * override, wrapping the real themed app; the inner PassiveMarkdown NoOp provider must still win
   * for rendered markdown, so [uris] staying empty across real glyph clicks IS the passivity proof
   * (plus the blocking ACTION_VIEW monitor at 0).
   */
  private class RecordingUriHandler : UriHandler {
    val uris = mutableListOf<String>()

    override fun openUri(uri: String) {
      uris.add(uri)
    }
  }

  private fun installOuterSpy(recorder: RecordingUriHandler) {
    compose.activityRule.scenario.onActivity { it.testUriHandlerOverride = recorder }
  }

  private fun clearOuterSpy() {
    compose.activityRule.scenario.onActivity { it.testUriHandlerOverride = null }
    compose.waitForIdle()
  }

  /** Diagnostic only (assertion-failure messages): every visible text node's rendered text. */
  private fun dumpVisibleTexts(): String =
    compose
      .onAllNodesWithText("", substring = true)
      .fetchSemanticsNodes()
      .mapNotNull { node ->
        node.config.getOrNull(SemanticsProperties.Text)?.joinToString(" | ") { it.text }
      }
      .joinToString("\n")

  // --- 0. FIT REGRESSION: transcript viewport must be nonzero and first turn visible ---

  @Test
  fun i_workspace_transcript_viewport_nonzero_and_first_turn_visible() {
    // Owner-approved PLAN behavioral check (2026-10-09): meaningful USABLE positive dimensions
    // + first turn actually displayed + composer reachable — NO arbitrary ratio number.
    val list = compose.onNodeWithTag("workspace-list").fetchSemanticsNode()
    val root = compose.onRoot().fetchSemanticsNode()
    val bounds = list.boundsInRoot
    assertTrue(
      "workspace-list ${list.size.width}x${list.size.height}px of root ${root.size.width}x${root.size.height}px — " +
        "transcript viewport must have positive usable width AND height",
      list.size.width > 0 && list.size.height > 0,
    )
    assertTrue(
      "workspace-list bounds $bounds must sit inside root bounds",
      bounds.bottom > bounds.top && bounds.top >= 0 && bounds.bottom <= root.size.height,
    )
    // First turn actually DISPLAYED (measured, not assumed). On the restored physical base
    // (1080x2340) two transcript nodes match; assert the FIRST one displayed (same intent,
    // disambiguated selector — not a weakening).
    compose.onAllNodesWithText("You (fixture)")[0].assertIsDisplayed()
    // Composer reachable and positive-sized.
    val composer =
      compose.onNodeWithText("Message agent (prototype fixture only)").fetchSemanticsNode()
    assertTrue(
      "composer ${composer.size.width}x${composer.size.height}px must be positive",
      composer.size.width > 0 && composer.size.height > 0,
    )
    // Gallery: the DEFAULT workspace state (initial history displayed, follow not yet acted on).
    capture("workspace-default")
  }

  // --- 0b. NATIVE PROFILE / BAR-APPEARANCE REGRESSION: actual device configuration, density,
  //        window resolution and real system-bar icon-appearance flags must match the run args.

  @Test
  fun j_native_profile_density_and_bar_appearance_match_run_args() {
    val expectedNight = theme == "dark"
    val (expectedW, expectedH, expectedDensity) =
      when (profile) {
        "short" -> Triple(320, 640, 160)
        "normal" -> Triple(1080, 2340, 440)
        else -> error("unapproved profile '$profile' (only short/normal are owner-approved)")
      }
    var observed: Triple<Boolean, Pair<Int, Int>, Int>? = null
    var flags: Pair<Boolean, Boolean>? = null
    compose.activityRule.scenario.onActivity { activity ->
      // ACTUAL runtime configuration (night mode + density + physical pixels), not the arg echo.
      val cfg = activity.resources.configuration
      val metrics = activity.resources.displayMetrics
      // ACTUAL WindowCompat flag state, read on the UI thread after attach/focus — the flags the
      // decor actually carries, not the intent captured in a closure.
      val controller =
        androidx.core.view.WindowCompat.getInsetsController(
          activity.window,
          activity.window.decorView,
        )
      observed =
        Triple(
          (cfg.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES,
          metrics.widthPixels to metrics.heightPixels,
          metrics.densityDpi,
        )
      flags = controller.isAppearanceLightStatusBars to controller.isAppearanceLightNavigationBars
    }
    val (actualNight, actualWH, actualDensity) =
      requireNotNull(observed) { "activity action never ran" }
    val (lightStatus, lightNav) = requireNotNull(flags) { "activity action never ran" }
    val (actualW, actualH) = actualWH
    assertEquals(
      "device night configuration must match theme arg '$theme'",
      expectedNight,
      actualNight,
    )
    assertEquals(
      "profile '$profile' physical width",
      expectedW,
      actualW,
    )
    assertEquals("profile '$profile' physical height", expectedH, actualH)
    assertEquals("profile '$profile' density", expectedDensity, actualDensity)
    assertEquals(
      "status-bar icon appearance must be light flags in light mode, dark flags in dark mode",
      !expectedNight,
      lightStatus,
    )
    assertEquals("navigation-bar icon appearance must match mode", !expectedNight, lightNav)
  }

  // --- 1. roster grouping + identity/job/session/status truth ---

  @Test
  fun a_roster_shows_groups_identity_job_session_status() {
    gotoRoster()
    compose.onNodeWithText("harus-mini (fixture)").assertExists()
    compose.onNodeWithText("mochi — refactor renderer").assertExists()
    compose.onNodeWithText("session sess-fixture-0001").assertExists()
    compose.onAllNodesWithText("settled")[0].assertExists()
    compose.onNodeWithTag("roster-list").performScrollToNode(hasText("lab-box (fixture)"))
    compose.onNodeWithText("lab-box (fixture)").assertExists()
    compose.onNodeWithText("kuri — backup sweep").assertExists()
    compose.onNodeWithText("disconnected").assertExists()
    capture("roster")
  }

  // --- 2. select / back / system back / reselect all presets ---

  @Test
  fun b_select_back_and_reselect_presets() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    compose.onNodeWithContentDescription("Back to roster").assertExists()
    compose.onNodeWithText("settled truth").assertExists()
    compose.activityRule.scenario.onActivity { activity ->
      activity.onBackPressedDispatcher.onBackPressed()
    }
    compose.onNodeWithText("mochi — refactor renderer").assertExists()

    compose.onNodeWithTag("roster-list").performScrollToNode(hasText("yuzu", substring = true))
    // Exact row literal, DISPLAYED precondition before tap (full roster row is "yuzu — watch CI",
    // so exact-match hasText("yuzu") never resolved — source-derived selector, not a missing
    // fixture).
    compose.onNodeWithText("yuzu — watch CI").assertIsDisplayed()
    compose.onNodeWithText("yuzu — watch CI").performClick()
    // Actual source strings (yuzu's status label is LIKELY_RUNNING, not "readonly"):
    compose.onNodeWithText("status: likely running (heuristic)").assertExists()
    compose.onNodeWithText("Read-only session — composer disabled").assertExists()
    capture("readonly-composer")
    compose.onNodeWithContentDescription("Back to roster").performClick()

    compose.onNodeWithTag("roster-list").performScrollToNode(hasText("kuri", substring = true))
    compose.onNodeWithText("kuri — backup sweep").assertIsDisplayed()
    compose.onNodeWithText("kuri — backup sweep").performClick()
    compose.onNodeWithText("Disconnected — composer disabled").assertExists()
    capture("disconnected-composer")
    compose.onNodeWithContentDescription("Back to roster").performClick()
    compose.onNodeWithText("mochi — refactor renderer").assertExists()
  }

  // --- 3. cross-session reset: composer text, expansion, thought and stream state do not leak ---

  @Test
  fun c_cross_session_state_reset() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    val toolToggle = compose.onAllNodesWithText("tool: read (tap to expand)")[0]
    toolToggle.performClick()
    compose
      .onNodeWithText("input: {\"path\": \"app/src/test/kotlin/ExampleTest.kt\"}")
      .assertExists()
    // Composer text + expanded collapsed thought also live in session state.
    compose.onNodeWithText("Message agent (prototype fixture only)").performTextInput("leak probe")
    compose.onNodeWithText("leak probe").assertExists()
    // Clear composer focus + request IME hide; bounded ACTUAL-inset condition (no sleep loops).
    compose.activityRule.scenario.onActivity { activity ->
      activity.currentFocus?.clearFocus()
      androidx.core.view.WindowCompat.getInsetsController(
          activity.window,
          activity.window.decorView,
        )
        .hide(WindowInsets.Type.ime())
    }
    compose.waitUntil(5_000) {
      var bottom = -1
      compose.activityRule.scenario.onActivity { activity ->
        bottom =
          activity.window.decorView.rootWindowInsets.getInsets(WindowInsets.Type.ime()).bottom
      }
      bottom == 0
    }
    // Bounded ACTUAL condition for the restored generation/control row before scrolling:
    compose.waitUntil(5_000) {
      compose.onAllNodesWithText("Next stream event").fetchSemanticsNodes().isNotEmpty()
    }
    compose.onNodeWithText("Next stream event").assertIsDisplayed()
    compose.onNodeWithText("generation 0 · event 0/4", substring = true).assertExists()
    // Scroll the correct workspace container to the target, assert DISPLAYED, single click.
    compose.onNodeWithTag("workspace-list").performScrollToNode(hasText("thinking — tap to expand"))
    compose.onAllNodesWithText("thinking — tap to expand")[0].assertIsDisplayed().performClick()
    compose
      .onNodeWithText(
        "The fixture test redacts thoughts; the parser must keep redacted content out of the body."
      )
      .assertExists()
    // Gallery: GENUINE viewport preconditions — thought body and tool output must be actually
    // DISPLAYED, not merely present offscreen. Assert displayed first; scroll only if offscreen.
    val thoughtBody =
      compose.onNodeWithText(
        "The fixture test redacts thoughts; the parser must keep redacted content out of the body."
      )
    try {
      thoughtBody.assertIsDisplayed()
    } catch (e: AssertionError) {
      compose
        .onNodeWithTag("workspace-list")
        .performScrollToNode(
          hasText(
            "The fixture test redacts thoughts; the parser must keep redacted content out of the body."
          )
        )
      thoughtBody.assertIsDisplayed()
    }
    capture("thinking-expanded")
    // Gallery: the expanded tool OUTPUT must also be actually DISPLAYED.
    val toolOutput =
      compose.onNodeWithText("input: {\"path\": \"app/src/test/kotlin/ExampleTest.kt\"}")
    try {
      toolOutput.assertIsDisplayed()
    } catch (e: AssertionError) {
      compose
        .onNodeWithTag("workspace-list")
        .performScrollToNode(hasText("input: {\"path\": \"app/src/test/kotlin/ExampleTest.kt\"}"))
      toolOutput.assertIsDisplayed()
    }
    capture("tool-expanded")
    // Gallery: expanded tool + expanded thought, captured in their ACTUAL asserted state.
    capture("expanded-tool-thought")
    compose.onNodeWithText("generation 0 · event 0/4", substring = true).assertExists()
    // Leave via a DIFFERENT session, then return: nothing may leak.
    compose.onNodeWithContentDescription("Back to roster").performClick()
    compose.onNodeWithText("yuzu — watch CI").performClick()
    compose.onNodeWithContentDescription("Back to roster").performClick()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    // Tool collapsed again:
    compose.onAllNodesWithText("tool: read (tap to expand)")[0].assertExists()
    val expanded =
      compose.onAllNodesWithText("input: {\"path\": \"app/src/test/kotlin/ExampleTest.kt\"}")
    assertEquals(0, expanded.fetchSemanticsNodes().size)
    // Composer text reset:
    assertEquals(0, compose.onAllNodesWithText("leak probe").fetchSemanticsNodes().size)
    // Thought collapsed again + fresh stream generation:
    compose.onAllNodesWithText("thinking — tap to expand")[0].assertExists()
    compose.onNodeWithText("generation 0 · event 0/4", substring = true).assertExists()
  }

  // --- 4. connected composer accepts text with actually visible IME ---

  @Test
  fun d_connected_composer_ime_visible() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    compose.onNodeWithText("Message agent (prototype fixture only)").performClick()
    compose
      .onNodeWithText("Message agent (prototype fixture only)")
      .performTextInput("fixture typing")
    compose.onNodeWithText("fixture typing").assertExists()
    // GENUINE soft IME: request show on the real window, then bounded-condition wait for the
    // IME inset to actually appear (performTextInput alone does NOT open a keyboard window;
    // focus alone is not proof).
    compose.activityRule.scenario.onActivity { activity ->
      androidx.core.view.WindowCompat.getInsetsController(
          activity.window,
          activity.window.decorView,
        )
        .show(WindowInsets.Type.ime())
    }
    var imeBottom = 0
    val deadline = System.currentTimeMillis() + 5_000
    while (System.currentTimeMillis() < deadline && imeBottom == 0) {
      compose.activityRule.scenario.onActivity { activity ->
        imeBottom =
          activity.window.decorView.rootWindowInsets.getInsets(WindowInsets.Type.ime()).bottom
      }
      if (imeBottom == 0) Thread.sleep(200)
    }
    assertTrue("IME inset bottom was $imeBottom (soft keyboard never shown)", imeBottom > 0)
    // The composer must sit ABOVE the visible IME (usable text entry, not covered).
    val composerText = compose.onNodeWithText("fixture typing")
    composerText.assertIsDisplayed()
    val composerNode = composerText.fetchSemanticsNode()
    assertTrue(
      "composer ${composerNode.size.width}x${composerNode.size.height}px must stay positive " +
        "with the IME visible (bounds Rect.ZERO never passes)",
      composerNode.size.width > 0 && composerNode.size.height > 0,
    )
    val composerBounds = composerNode.boundsInRoot
    val screenHeight = compose.onRoot().fetchSemanticsNode().size.height
    assertTrue(
      "composer bottom ${composerBounds.bottom} not above IME top ${screenHeight - imeBottom}",
      composerBounds.bottom <= screenHeight - imeBottom,
    )
    // READABLE-GLYPH proof (P0): positive size alone is a false positive when the outlined field
    // clips the typed line to a sliver (c4-short-debug/stepc-short-light-connected-ime.png).
    // (1) stock-M3 minimum outlined-field height: 56dp total field;
    val minFieldPx = with(compose.density) { 56.dp.toPx() }
    assertTrue(
      "outlined field ${composerNode.size.height}px is below the stock-M3 56dp minimum " +
        "($minFieldPx px) — typed text would clip",
      composerNode.size.height >= minFieldPx,
    )
    // (2) the editable text node is at least one full laid-out glyph line tall (no vertical clip):
    val captured = mutableListOf<TextLayoutResult>()
    val layoutAction =
      composerText.fetchSemanticsNode().config[SemanticsActions.GetTextLayoutResult].action
        ?: error("composer exposes no text layout result action")
    check(layoutAction.invoke(captured)) { "text layout result action returned false" }
    val layout = captured.first()
    val lastLineBottom = layout.getLineBottom(layout.lineCount - 1)
    assertTrue(
      "editable text ${composerNode.size.height}px shorter than its laid-out last line " +
        "$lastLineBottom px — glyphs are CLIPPED, not readable",
      composerNode.size.height >= lastLineBottom,
    )
    capture("connected-ime")
    // Settle: dismiss the IME and wait BOUNDED for the inset to actually clear + the hidden
    // control rows to restore, so later tests start from a clean window state.
    compose.activityRule.scenario.onActivity { activity ->
      activity.currentFocus?.clearFocus()
      androidx.core.view.WindowCompat.getInsetsController(
          activity.window,
          activity.window.decorView,
        )
        .hide(WindowInsets.Type.ime())
    }
    compose.waitUntil(5_000) {
      var bottom = -1
      compose.activityRule.scenario.onActivity { activity ->
        bottom =
          activity.window.decorView.rootWindowInsets.getInsets(WindowInsets.Type.ime()).bottom
      }
      bottom == 0
    }
  }

  // --- 5. all 5 unavailable actions with SIGHTED reasons, reachable, not truncated ---

  @Test
  fun e_all_unavailable_actions_with_visible_reasons_reachable() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    val labels =
      listOf("Queue steer", "Follow-up", "Abort", "Delivery receipts", "Model / effort / context")
    val reasons =
      listOf(
        "steer queue intents not on the wire yet",
        "follow-up queue intents not on the wire yet",
        "no abort path implemented",
        "receipts not modeled",
        "not exposed by the bridge",
      )
    // Open the native capability sheet via the header icon (source-derived contentDescription);
    // scroll THE SHEET itself; every tap target asserted
    // visible first — no index magic into workspace-list.
    compose.onNodeWithContentDescription("Capabilities: 5 unavailable").performClick()
    labels.forEachIndexed { i, label ->
      compose.onNodeWithTag("capability-sheet").performScrollToNode(hasText(label))
      compose.onNodeWithText(label).assertIsDisplayed()
      compose.onNodeWithText(reasons[i]).assertIsDisplayed()
    }
    capture("unavailable-capabilities")
    compose.activityRule.scenario.onActivity { activity ->
      activity.onBackPressedDispatcher.onBackPressed()
    }
  }

  // --- 6. streaming NEXT delta + AUTHORITATIVE replacement + reset ---

  @Test
  fun f_stream_delta_then_authoritative_replacement_and_reset() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    scrollToText("Streaming fixture")
    // Explicit JUMP chip FIRST (the only affordance that both arms follow and performs the
    // programmatic actual-tail jump; a bare scrollTo leaves the unflagged-scroll disarm path
    // free to flip follow off before the assertion).
    compose.onNodeWithText("Follow latest").performClick()
    compose.onNodeWithText("Follow latest").assert(isSelected())
    compose.onNodeWithText("Next stream event").performClick()
    compose.waitForIdle()
    // Real rendered delta, actually displayed at the tail (not merely composed offscreen).
    compose.onNodeWithTag("workspace-list").performScrollToNode(hasTestTag("stream-body"))
    // performScrollToNode itself can disarm following (unflagged scroll away from the tail);
    // re-establish the EXPLICIT jump/follow intent before later appends are observed.
    compose.onNodeWithText("Follow latest").performClick()
    compose.onNodeWithText("Follow latest").assert(isSelected())
    compose.onNodeWithText("The fixture", substring = true).assertExists().assertIsDisplayed()
    compose.onNodeWithText("Next stream event").performClick()
    compose.onNodeWithText("Next stream event").performClick()
    compose.onNodeWithText("Next stream event").performClick()
    compose.waitForIdle()
    // Authoritative REPLACEMENT: full plain text, no old markup ever rendered.
    // Authoritative REPLACEMENT (bounded framework wait for the new generation's render).
    compose.waitUntil(5_000) {
      compose
        .onAllNodesWithText(
          "The fixture answer streams and ends with an authoritative replacement.",
          substring = true,
        )
        .fetchSemanticsNodes()
        .isNotEmpty()
    }
    compose
      .onNodeWithText(
        "The fixture answer streams and ends with an authoritative replacement.",
        substring = true,
      )
      .assertExists()
      .assertIsDisplayed()
    // PLAIN rendered text: the old markup "**in chunks**" is never rendered as literal stars, so
    // asserting the literal would always pass; assert the rendered phrase disappears.
    assertTrue(compose.onAllNodesWithText("in chunks").fetchSemanticsNodes().isEmpty())
    capture("stream-authoritative")
    // Reset: NEW generation 0 / event 0 with an EMPTY body — no old content anywhere.
    compose.onNodeWithText("Reset stream").performClick()
    compose.waitForIdle()
    compose.onNodeWithText("generation 0 · event 0/4", substring = true).assertExists()
    assertEquals(
      0,
      compose.onAllNodesWithText("The fixture answer", substring = true).fetchSemanticsNodes().size,
    )
  }

  /**
   * Every test leaves the test-only overrides/observer cleared and IME settled, whatever the
   * outcome (c/d after-test settlement even on assertion failure).
   */
  @org.junit.After
  fun clearOverridesAndSettle() {
    compose.activityRule.scenario.onActivity { it.longFinalOverride = null }
    StreamGrowthObserver.reset()
    compose.activityRule.scenario.onActivity { activity ->
      activity.currentFocus?.clearFocus()
      androidx.core.view.WindowCompat.getInsetsController(
          activity.window,
          activity.window.decorView,
        )
        .hide(WindowInsets.Type.ime())
    }
  }

  // --- 7. drag from tail = manual reading (no steal); jump resumes to actual bottom ---

  @Test
  fun g_drag_from_tail_disables_follow_jump_resumes() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    scrollToText("Streaming fixture")
    // Long-final input (test-only): the authoritative step replaces with a body TALLER than the
    // viewport, so tail convergence is proven on a real long final item. Default flow unchanged.
    compose.activityRule.scenario.onActivity {
      it.longFinalOverride = PiFixtures.Stream.longAuthoritative
    }
    // Precondition via the EXPLICIT JUMP chip (pinned chrome, always composed):
    compose.onNodeWithText("Follow latest").performClick()
    compose.onNodeWithText("Follow latest").assert(isSelected())
    compose.waitForIdle()
    // Jump reached the ACTUAL stream BODY bottom (not the generation header bottom).
    val listBounds = compose.onNodeWithTag("workspace-list").fetchSemanticsNode().boundsInRoot
    val bodyBounds = compose.onNodeWithTag("stream-body").fetchSemanticsNode().boundsInRoot
    assertTrue(
      "stream body bottom ${bodyBounds.bottom} below list viewport end ${listBounds.bottom}",
      bodyBounds.bottom <= listBounds.bottom + 2f,
    )
    // User reads EARLIER content: swipe DOWN (tail → older). A single gesture.
    compose.onNodeWithTag("workspace-list").performTouchInput { swipeDown() }
    compose.onNodeWithText("Follow latest").assert(!isSelected())
    // Parked reading anchor: actual first-visible index + pixel offset.
    fun anchor(): String =
      compose
        .onNodeWithTag("workspace-list")
        .fetchSemanticsNode()
        .config[SemanticsProperties.ContentDescription]
        .single()
    val anchorBeforeAppend = anchor()
    // Append while manual reading: follow stays disarmed AND the viewport anchor is unchanged.
    compose.onNodeWithText("Next stream event").performClick()
    compose.onNodeWithText("Follow latest").assert(!isSelected())
    assertEquals(anchorBeforeAppend, anchor())
    capture("manual-reading")
    // Explicit jump (the chip itself is the jump affordance) resumes follow...
    compose.onNodeWithText("Follow latest").performClick()
    compose.onNodeWithText("Follow latest").assert(isSelected())
    compose.waitForIdle()
    // Drive to the authoritative step so the FINAL body is the long replacement text, then jump.
    compose.onNodeWithText("Next stream event").performClick()
    compose.onNodeWithText("Next stream event").performClick()
    compose.onNodeWithText("Next stream event").performClick()
    compose.onNodeWithText("Follow latest").assert(isSelected())
    compose.waitForIdle()
    // ...and reaches the ACTUAL bottom: the LAST stream BODY's UNCLIPPED bottom edge at the
    // viewport end (boundsInRoot is clipped and cannot prove geometry for a tall final body).
    fun bodyMetrics(): Pair<Int, Float> {
      val desc =
        compose
          .onNodeWithTag("stream-body")
          .fetchSemanticsNode()
          .config[SemanticsProperties.ContentDescription]
          .single()
      val parts = desc.removePrefix("stream-body-metrics:").split(":")
      return parts[0].toInt() to parts[1].toFloat()
    }
    val (bodyHeight, bodyBottom) = bodyMetrics()
    val listEnd = compose.onNodeWithTag("workspace-list").fetchSemanticsNode().boundsInRoot.bottom
    val viewportH = compose.onNodeWithTag("workspace-list").fetchSemanticsNode().size.height
    assertTrue(
      "long final body $bodyHeight px must exceed the $viewportH px viewport",
      bodyHeight > viewportH,
    )
    assertTrue(
      "tail body bottom $bodyBottom must sit at the list viewport end $listEnd",
      bodyBottom <= listEnd + 2f && bodyBottom >= listEnd - viewportH,
    )
  }

  // --- 7c. size growth DURING another jump/animation is deferred, never dropped ---

  @Test
  fun g3_size_growth_during_jump_is_not_dropped() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    scrollToText("Streaming fixture")
    // Long final input so the last authoritative growth is large and the jump animates long
    // enough that the growth lands while another programmatic scroll is still in flight.
    compose.activityRule.scenario.onActivity {
      it.longFinalOverride = PiFixtures.Stream.longAuthoritative
    }
    compose.onNodeWithText("Follow latest").performClick()
    compose.onNodeWithText("Follow latest").assert(isSelected())
    // Drive to the LAST delta step (3/4): the NEXT event is the authoritative replacement that
    // consumes longFinalOverride. Ordinary performClick idles — fine here, still pre-final.
    repeat(3) { compose.onNodeWithText("Next stream event").performClick() }
    compose.onNodeWithText("event 3/4", substring = true).assertExists()
    // Reset the observer to THIS run, then capture the PRE-EVENT body-size baseline while the
    // generation-1 body is still visible/parsed (event 3/4 delta content rendered).
    StreamGrowthObserver.reset()
    compose.waitUntil(5_000) {
      compose.onAllNodesWithText("The fixture", substring = true).fetchSemanticsNodes().isNotEmpty()
    }
    compose.onNodeWithText("The fixture", substring = true).assertIsDisplayed()
    fun streamMetrics(): Pair<Int, Float> {
      val desc =
        compose
          .onNodeWithTag("stream-body")
          .fetchSemanticsNode()
          .config[SemanticsProperties.ContentDescription]
          .single()
      val parts = desc.removePrefix("stream-body-metrics:").split(":")
      return parts[0].toInt() to parts[1].toFloat()
    }
    val baselineSize = streamMetrics().first
    // Park EARLIER like a manual reader: one gesture disarms follow (same proof as g).
    compose.onNodeWithTag("workspace-list").performTouchInput { swipeDown() }
    compose.onNodeWithText("Follow latest").assert(!isSelected())
    compose.waitForIdle()
    // Prefetch the REAL native OnClick callbacks while fully idle (no idle-waiting afterwards).
    val followAction =
      compose
        .onNodeWithText("Follow latest")
        .fetchSemanticsNode()
        .config[SemanticsActions.OnClick]
        .action ?: error("no OnClick on Follow latest")
    val nextAction =
      compose
        .onNodeWithText("Next stream event")
        .fetchSemanticsNode()
        .config[SemanticsActions.OnClick]
        .action ?: error("no OnClick on Next stream event")
    val viewportH = compose.onNodeWithTag("workspace-list").fetchSemanticsNode().size.height
    // Genuine bounded overlap on the MAIN thread: the chip jump starts its programmatic scroll
    // animation, and the authoritative final-event callback is posted right behind it, so the
    // long body arrives WHILE that scroll is still in flight. No freeze/sleep/fake model.
    compose.activityRule.scenario.onActivity { activity ->
      // We ARE on the main thread: start the chip jump now, then queue the authoritative
      // final-event callback one loop iteration later so it lands mid-jump.
      followAction()
      android.os.Handler(android.os.Looper.getMainLooper()).post { nextAction() }
    }
    fun metrics(): Pair<Int, Float> = streamMetrics()
    // The long ACTUAL FINAL body's unclipped height must exceed the viewport and its bottom
    // converge to the viewport end, with follow re-armed by the chip jump — all bounded.
    compose.waitUntil(10_000) {
      val (h, bottom) = metrics()
      val listEnd = compose.onNodeWithTag("workspace-list").fetchSemanticsNode().boundsInRoot.bottom
      h > viewportH && bottom <= listEnd + 2f
    }
    compose.waitForIdle()
    compose.onNodeWithText("Follow latest").assert(isSelected())
    compose.onNodeWithText("event 4/4 · done", substring = true).assertExists()
    val (h, bottom) = metrics()
    val finalHeight = h
    val listEnd = compose.onNodeWithTag("workspace-list").fetchSemanticsNode().boundsInRoot.bottom
    assertTrue("long final body $h px must exceed the $viewportH px viewport", h > viewportH)
    assertTrue(
      "tail body bottom $bottom must converge to the list viewport end $listEnd",
      bottom <= listEnd + 2f && bottom >= listEnd - viewportH,
    )
    // READ-ONLY proof the growth was actually OBSERVED while a programmatic scroll was in flight
    // (recorded by the app's size-convergence collector when it had to drop the growth), scoped
    // to THIS run: the recorded size must exceed the pre-event baseline AND the viewport, match
    // the actual current long body height, and the in-flight counter must be genuinely positive.
    val observed = StreamGrowthObserver.lastObservation
    val match =
      Regex("growth-during-scroll:size=(\\d+):busy=(\\w+):programmatic=(\\d+)").find(observed)
        ?: error("no growth-during-scroll observation recorded during the overlap, got: $observed")
    val (recordedSize, recordedProgrammatic) =
      match.destructured.let { it.component1().toInt() to it.component3().toInt() }
    assertTrue(
      "recorded growth $recordedSize must exceed the pre-event baseline $baselineSize",
      recordedSize > baselineSize,
    )
    assertTrue(
      "recorded growth $recordedSize must exceed the $viewportH px viewport",
      recordedSize > viewportH,
    )
    assertEquals(finalHeight, recordedSize)
    assertTrue(
      "in-flight programmatic counter must be positive in the record, got: $observed",
      recordedProgrammatic > 0,
    )
    capture("g3-growth-during-jump")
  }

  // --- 7b. partial reset DURING generation 0 clears rendering state too ---

  @Test
  fun g2_reset_during_generation0_clears_stream_body() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    compose.onNodeWithText("Follow latest").performClick()
    compose.onNodeWithText("Follow latest").assert(isSelected())
    // One delta in generation 0, then a partial reset (generation stays 0).
    compose.onNodeWithText("Next stream event").performClick()
    // The rendered delta requires async Markdown parsing OUTSIDE Compose idle — bounded actual
    // render condition first, then the DISPLAYED assertion (no blind idle assert).
    // Bounded diagnostics (no timeout extension): capture body metrics / generation / visible
    // texts and the ORIGINAL PNG BEFORE any throw, to distinguish lost virtualized body,
    // cancelled parser, stream-not-advanced, IME or layout from a genuinely slow parse.
    val rendered = runCatching {
      compose.waitUntil(5_000) {
        compose
          .onAllNodesWithText("The fixture", substring = true)
          .fetchSemanticsNodes()
          .isNotEmpty()
      }
      true
    }
      .isSuccess
    if (!rendered) {
      val bodyMetrics = runCatching {
        compose
          .onNodeWithTag("stream-body")
          .fetchSemanticsNode()
          .config
          .getOrNull(SemanticsProperties.ContentDescription)
          ?.joinToString()
      }
        .getOrDefault("stream-body-node-absent")
      val generationNodes =
        compose.onAllNodesWithText("generation", substring = true).fetchSemanticsNodes().size
      println(
        "G2-DIAG rendered=false bodyMetrics=$bodyMetrics generationNodes=$generationNodes\n" +
          dumpVisibleTexts()
      )
      capture("g2-diag-before-throw")
    }
    compose.onNodeWithText("The fixture", substring = true).assertExists().assertIsDisplayed()
    compose.onNodeWithText("Reset stream").performClick()
    compose.waitForIdle()
    compose.onNodeWithText("generation 0 · event 0/4", substring = true).assertExists()
    assertEquals(
      0,
      compose.onAllNodesWithText("The fixture", substring = true).fetchSemanticsNodes().size,
    )
    // Keep the g2 partial-reset semantics; add a bound on the native pending container so an
    // apppending-first-chunk collapse cannot silently lose composition (asserted after fix).
    compose.onNodeWithText("stream ready — no content yet").assertExists().assertIsDisplayed()
  }

  // --- 8. passive URIs: zero ACTION_VIEW across all structured node taps ---

  @Test
  fun h_passive_uris_zero_external_launches() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    val monitor = newUriMonitor()
    val spy = RecordingUriHandler()
    installOuterSpy(spy)
    try {
      // Tap the actual LINK SPAN glyph rectangle (via GetTextLayoutResult), not the merged
      // paragraph center which can miss the annotation entirely.
      scrollToText("heading link")
      clickLinkSpan("heading link")
      scrollToText("list link")
      clickLinkSpan("list link")
      scrollToText("nested link")
      clickLinkSpan("nested link")
      scrollToText("quote link")
      clickLinkSpan("quote link")
      scrollToText("table link")
      clickLinkSpan("table link")
      assertEquals("an ACTION_VIEW escaped the passive policy", 0, monitor.hits)
      assertEquals(
        "the inner NoOp handler did not win over the outer spy",
        emptyList<String>(),
        spy.uris,
      )
      capture("passive-structured")
    } finally {
      // No rogue browser/monitor/outer override may outlive this test.
      InstrumentationRegistry.getInstrumentation().removeMonitor(monitor)
      clearOuterSpy()
    }
  }

  // --- 9. real STREAMING structured content: every node type rendered through the streaming
  //        state path, with a REAL image, and ZERO external ACTION_VIEW launches.

  @Test
  fun s_streaming_structured_authoritative_rendered_passive() {
    gotoRoster()
    compose.onNodeWithText("mochi — refactor renderer").performClick()
    scrollToText("Streaming fixture")
    // Same instance-authoritative override path as the g journeys: the structured payload with a
    // REAL `![alt](url)` image arrives through the streaming text_end replacement (real inner
    // NoOp provider + native activity theme path — no static renderer substitute).
    compose.activityRule.scenario.onActivity {
      it.longFinalOverride = PiFixtures.Stream.structuredAuthoritative
    }
    val monitor = newUriMonitor()
    val spy = RecordingUriHandler()
    installOuterSpy(spy)
    try {
      compose.onNodeWithText("Follow latest").performClick()
      compose.onNodeWithText("Follow latest").assert(isSelected())
      repeat(4) { compose.onNodeWithText("Next stream event").performClick() }
      // Async streaming parse: bounded actual-render condition, then DISPLAYED per node.
      compose.waitUntil(5_000) {
        compose
          .onAllNodesWithText("stream heading link", substring = true)
          .fetchSemanticsNodes()
          .isNotEmpty()
      }
      listOf("stream heading link", "stream list link", "stream nested link", "stream quote link")
        .forEach { label ->
          compose
            .onNodeWithTag("workspace-list")
            .performScrollToNode(hasText(label, substring = true))
          compose.onNodeWithText(label, substring = true).assertIsDisplayed()
        }
      // REAL image rendered as the passive substitution of its alt (never fetched). The TABLE is
      // asserted against the LAST-item scroll: a direct scrollToNode to the table row leaves it a
      // bottom-edge sliver (minimal-scroll semantics), so scroll to the unique stream image (last
      // item) and require the table fully visible above it. No weakened display assertion.
      // Identity note: the streaming (incremental) parser's block IMAGE node carries NO resolvable
      // LINK_TEXT — native resolveImageAlt returns null against BOTH model.content and the
      // canonical
      // full source (0.45.0 API; dump archived). The declared PassivePolicy URL fallback IS the
      // rendered identity; alt text is preserved on the static (full-parse) path.
      try {
        compose.waitUntil(5_000) {
          compose
            .onAllNodesWithText(
              "[image: https://example.invalid/stream-fixture.png]",
              substring = true,
            )
            .fetchSemanticsNodes()
            .isNotEmpty()
        }
      } catch (e: Throwable) {
        throw AssertionError(
          "stream block image never rendered as its ALT passive text; visible texts:\n" +
            dumpVisibleTexts(),
          e,
        )
      }
      compose
        .onNodeWithTag("workspace-list")
        .performScrollToNode(
          hasText("[image: https://example.invalid/stream-fixture.png]", substring = true)
        )
      compose.onNodeWithText("s table link", substring = true).assertIsDisplayed()
      compose
        .onNodeWithText("[image: https://example.invalid/stream-fixture.png]")
        .assertIsDisplayed()
      // REAL link activation: click each streamed structured link's GLYPH RECTANGLE. Passivity is
      // proven by the outer recording spy staying empty (inner NoOp won) AND the ACTION_VIEW
      // monitor staying at 0 — DISPLAYED-only would be vacuous.
      listOf("stream heading link", "stream list link", "stream nested link", "stream quote link")
        .forEach { label ->
          scrollToText(label)
          compose.onNodeWithText(label, substring = true).assertIsDisplayed()
          clickLinkSpan(label)
        }
      // Table link: anchor via the unique last stream image (scroll-to-table alone leaves a
      // bottom-edge sliver); the fully-visible table is composed above it — click its glyph rect.
      compose
        .onNodeWithTag("workspace-list")
        .performScrollToNode(hasText("[image: https://example.invalid/stream-fixture.png]"))
      compose.onNodeWithText("s table link", substring = true).assertIsDisplayed()
      clickLinkSpan("s table link")
      compose
        .onNodeWithText("[image: https://example.invalid/stream-fixture.png]")
        .assertIsDisplayed()
      assertEquals("an ACTION_VIEW escaped the passive policy", 0, monitor.hits)
      assertEquals(
        "the inner NoOp handler did not win over the outer spy",
        emptyList<String>(),
        spy.uris,
      )
      compose.onNodeWithText("event 4/4 · done", substring = true).assertExists()
      assertEquals("an ACTION_VIEW escaped the passive policy", 0, monitor.hits)
      capture("stream-structured")
    } finally {
      InstrumentationRegistry.getInstrumentation().removeMonitor(monitor)
      clearOuterSpy()
    }
  }

  /** Clicks the precise glyph rectangle of [linkLabel] inside its containing text node. */
  private fun clickLinkSpan(linkLabel: String) {
    val interaction = compose.onNodeWithText(linkLabel, substring = true)
    val captured = mutableListOf<TextLayoutResult>()
    val action =
      interaction.fetchSemanticsNode().config[SemanticsActions.GetTextLayoutResult].action
        ?: error("node exposes no text layout result action")
    check(action.invoke(captured)) { "text layout result action returned false" }
    val layout = captured.first()
    val fullText = layout.layoutInput.text.text
    val start = fullText.indexOf(linkLabel)
    check(start >= 0) { "link label '$linkLabel' not present in rendered text" }
    var rect: Rect = layout.getBoundingBox(start)
    for (i in start + 1 until start + linkLabel.length) {
      val b = layout.getBoundingBox(i)
      rect =
        Rect(
          left = minOf(rect.left, b.left),
          top = minOf(rect.top, b.top),
          right = maxOf(rect.right, b.right),
          bottom = maxOf(rect.bottom, b.bottom),
        )
    }
    interaction.performTouchInput { click(rect.center) }
  }
}
