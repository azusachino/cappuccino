package com.azusachino.cappuccino.prototype.logic

import com.azusachino.cappuccino.prototype.fixture.PiFixtures

/**
 * Pure player for the streaming fixture, USED directly by the Compose workspace UI.
 *
 * Models Pi's documented `message_update` progression: `text_delta` chunks append, and `text_end`
 * delivers the authoritative full text that REPLACES everything accumulated.
 *
 * Reset strategy (mikepenz 0.45.0 `StreamingMarkdownState` is verified append-only with no
 * replacement API): an authoritative event bumps [generation]; the UI keys its streaming state on
 * [generation], creating a fresh state seeded with the authoritative text. The player does NOT
 * claim incremental replacement inside one library state.
 *
 * The [StreamReducer] runs in parallel as the authoritative content model; tests assert the
 * chunk-sequence rebuild equals the reducer's result (deltas then replacement).
 */
data class StreamPlayer(
  val generation: Int = 0,
  val chunks: List<String> = emptyList(),
  val step: Int = 0,
  val reducer: StreamReducer = StreamReducer(),
) {
  val totalSteps: Int = PiFixtures.Stream.deltas.size + 1

  val finished: Boolean
    get() = step >= totalSteps

  /**
   * Advance one fixture event. Delta steps append the next chunk to the current generation; the
   * authoritative step starts a NEW generation (UI state reset) whose single chunk is the full
   * replacement text.
   */
  fun next(): StreamPlayer =
    when {
      step < PiFixtures.Stream.deltas.size -> {
        val delta = PiFixtures.Stream.deltas[step]
        copy(step = step + 1, chunks = chunks + delta, reducer = reducer.applyDelta(delta))
      }
      step == PiFixtures.Stream.deltas.size ->
        StreamPlayer(
          generation = generation + 1,
          chunks = listOf(PiFixtures.Stream.authoritative),
          step = step + 1,
          reducer = reducer.applyAuthoritativeReplacement(PiFixtures.Stream.authoritative),
        )
      else -> this
    }

  fun reset(): StreamPlayer = StreamPlayer()

  /**
   * Advance one fixture event; when [authoritativeOverride] is non-null AND the next event is the
   * authoritative step, use it as the replacement text instead of the fixture default (test-only
   * long-final input). The default flow and all model tests never pass an override.
   */
  fun nextOr(authoritativeOverride: String?): StreamPlayer =
    if (authoritativeOverride != null && step == PiFixtures.Stream.deltas.size)
      StreamPlayer(
        generation = generation + 1,
        chunks = listOf(authoritativeOverride),
        step = step + 1,
        reducer = reducer.applyAuthoritativeReplacement(authoritativeOverride),
      )
    else next()

  /** The generation's chunks a fresh streaming state must be seeded with after a reset. */
  fun seedChunks(forGeneration: Int): List<String> =
    if (forGeneration == generation) chunks else emptyList()
}
