package com.azusachino.cappuccino.prototype.logic

import com.azusachino.cappuccino.prototype.fixture.PiFixtures
import com.azusachino.cappuccino.prototype.model.AgentIdentity
import com.azusachino.cappuccino.prototype.model.AgentRow
import com.azusachino.cappuccino.prototype.model.AgentStatus
import com.azusachino.cappuccino.prototype.model.CompletionTruth
import com.azusachino.cappuccino.prototype.model.Connectivity
import com.azusachino.cappuccino.prototype.model.MachineGroup

/** Selection + truthfulness state for the prototype. Pure logic, JVM-testable. */
data class WorkspaceState(val selected: AgentIdentity?) {

  fun select(identity: AgentIdentity): WorkspaceState = copy(selected = identity)

  /** The roster row matching the current selection, or null when none matches (fail-closed). */
  fun selectedRow(roster: List<MachineGroup>): AgentRow? =
    roster.asSequence().flatMap { it.agents }.firstOrNull { it.identity.key == selected?.key }

  /** Header label must distinguish settled truth from heuristic labels. */
  fun headerStatusLabel(row: AgentRow?): String? =
    row?.status?.label?.takeIf {
      row.status.truth == CompletionTruth.SETTLED || row.status.truth == CompletionTruth.HEURISTIC
    }

  fun isSettledTruth(row: AgentRow?): Boolean = row?.status?.truth == CompletionTruth.SETTLED

  /** Composer enabled only when connected; readonly/disconnected are explicit disabled states. */
  fun composerEnabled(connectivity: Connectivity): Boolean = connectivity == Connectivity.CONNECTED

  fun composerPlaceholder(connectivity: Connectivity): String =
    when (connectivity) {
      Connectivity.CONNECTED -> "Message agent (prototype fixture only)"
      Connectivity.READONLY -> "Read-only session — composer disabled"
      Connectivity.DISCONNECTED -> "Disconnected — composer disabled"
    }

  companion object {
    fun initial(): WorkspaceState = WorkspaceState(PiFixtures.defaultSelection)

    /** Statuses that must never be presented as settled truth. */
    val nonSettledStatuses: List<AgentStatus> =
      AgentStatus.entries.filter { it.truth != CompletionTruth.SETTLED }
  }
}
