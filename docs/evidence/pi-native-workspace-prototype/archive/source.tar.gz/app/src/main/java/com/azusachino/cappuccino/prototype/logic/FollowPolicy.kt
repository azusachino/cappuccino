package com.azusachino.cappuccino.prototype.logic

/**
 * N-02 follow-latest geometry + intent policy. Pure and JVM-tested; USED by the Compose workspace
 * viewport collector (PrototypeApp) — no shadow helpers.
 *
 * Actual-tail definition: the LAST item is visible AND its bottom edge is within [TAIL_EPSILON_PX]
 * of the viewport end. Index-proximity alone ("last index - 2/3") is explicitly NOT the tail.
 */
object FollowPolicy {

  const val TAIL_EPSILON_PX = 2

  /**
   * True only when item [lastIndex] is the final item of [total] and its bottom edge
   * ([lastItemEndOffset]) sits at or tolerably near [viewportEnd]. Null/empty inputs (empty list,
   * no visible items) are safely false.
   */
  fun isAtActualTail(
    lastIndex: Int?,
    lastItemEndOffset: Int?,
    viewportEnd: Int?,
    total: Int,
    epsilon: Int = TAIL_EPSILON_PX,
  ): Boolean {
    if (total <= 0 || lastIndex == null || lastItemEndOffset == null || viewportEnd == null)
      return false
    if (lastIndex != total - 1) return false
    return lastItemEndOffset <= viewportEnd + epsilon
  }

  /**
   * Single intent transition used verbatim by the Compose collector. Returns the new following
   * state, or `null` for "write nothing, preserve current intent".
   *
   * - `programmatic` (our own auto-scroll/jump in flight): NEVER flips intent in either direction —
   *   programmatic movement cannot turn a false intent true or a true one false. (Callers reset the
   *   programmatic guard in `try/finally` so a cancelled or errored programmatic scroll can never
   *   leave the guard stuck true.)
   * - idle at the actual tail: resumes following.
   * - active USER gesture away from the tail: disarms — even when the drag STARTED at the tail
   *   (start position is irrelevant; the observer disengages as soon as the user is actively
   *   scrolling and off the tail).
   * - anything else (notably content growth while idle away from the tail): preserve.
   */
  fun followTransition(atTail: Boolean, userActiveDrag: Boolean, programmatic: Boolean): Boolean? =
    when {
      programmatic -> null
      atTail -> true
      userActiveDrag -> false
      else -> null
    }
}
