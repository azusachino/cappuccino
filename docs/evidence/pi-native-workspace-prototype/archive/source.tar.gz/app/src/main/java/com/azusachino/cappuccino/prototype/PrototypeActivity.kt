package com.azusachino.cappuccino.prototype

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.UriHandler
import androidx.core.view.WindowCompat
import com.azusachino.cappuccino.prototype.ui.PrototypeApp

/**
 * Prototype-only activity. This application is never installed on a device in Step B; gates are
 * dependency resolve + assemble + lint + JVM tests only.
 */
class PrototypeActivity : ComponentActivity() {
  /**
   * Test-only injection point: when non-null, the streaming authoritative step uses this text
   * (long-final g journey). Never set in production; default fixture flow unchanged.
   */
  @Volatile var longFinalOverride: String? = null

  /**
   * Test-only OUTER URI-handler override (snapshot-backed INSTANCE state, not a static/global
   * policy change). Default null: the normal host handler stands. When set by a test through the
   * actual themed activity, the real [PrototypeApp] is wrapped in an outer
   * `CompositionLocalProvider(LocalUriHandler provides …)` — no duplicated app/theme tree. The
   * INNER `PassiveMarkdown` NoOp provider must still win for rendered markdown (asserted by
   * recordings staying at 0 across real link clicks).
   */
  var testUriHandlerOverride: UriHandler? by mutableStateOf(null)

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    // Edge-to-edge so imePadding()/insets are real and the activity owns system-bar
    // icon appearance (resolved natively from the same light/dark resolution below).
    WindowCompat.setDecorFitsSystemWindows(window, false)
    setContent {
      // Fit fix (Step C): stock M3 light/dark resolution — the prototype previously
      // rendered always-light regardless of system theme. The activity owns the
      // system-bar icon appearance, resolved from the same light/dark decision.
      val dark = isSystemInDarkTheme()
      androidx.compose.runtime.SideEffect {
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars =
          !dark
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars =
          !dark
      }
      MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        // ONE stable provider slot at the root: the override (when set) replaces the host
        // handler inside an unconditional CompositionLocalProvider, so installing/clearing the
        // test spy never changes the slot-table hierarchy or remounts the app tree. The INNER
        // PassiveMarkdown NoOp provider still wins for rendered markdown.
        val currentHandler = LocalUriHandler.current
        CompositionLocalProvider(
          LocalUriHandler provides (testUriHandlerOverride ?: currentHandler)
        ) {
          PrototypeApp(longFinalAuthoritative = { this@PrototypeActivity.longFinalOverride })
        }
      }
    }
  }
}
