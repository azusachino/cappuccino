package com.azusachino.cappuccino.prototype.logic

import com.azusachino.cappuccino.prototype.fixture.PiFixtures

/**
 * Pure reducer for Pi `message_update`-shaped streaming: `text_delta` appends chunks, `text_end`
 * carries the authoritative full text that REPLACES everything accumulated.
 *
 * Verified against the mikepenz 0.45.0 sources: `StreamingMarkdownState.append(chunk)` is
 * append-only (no replacement API). Authoritative replacement therefore happens HERE; the reduced
 * result is what gets appended into a fresh renderer streaming state.
 */
data class StreamReducer(val content: String = "") {

  fun applyDelta(chunk: String): StreamReducer = copy(content = content + chunk)

  /** `text_end`: the full text is authoritative — it replaces prior accumulated content. */
  fun applyAuthoritativeReplacement(fullText: String): StreamReducer = copy(content = fullText)

  companion object {
    /** Replay the fixture stream end-to-end; asserts the replacement wins in tests. */
    fun replayFixture(): StreamReducer =
      PiFixtures.Stream.deltas
        .fold(StreamReducer()) { r, d -> r.applyDelta(d) }
        .applyAuthoritativeReplacement(PiFixtures.Stream.authoritative)
  }
}
