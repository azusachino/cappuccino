package com.azusachino.cappuccino.prototype.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.UriHandler
import com.azusachino.cappuccino.prototype.logic.PassivePolicy
import com.mikepenz.markdown.annotator.annotatorSettings
import com.mikepenz.markdown.compose.Markdown
import com.mikepenz.markdown.compose.components.markdownComponents
import com.mikepenz.markdown.compose.elements.MarkdownHighlightedCodeBlock
import com.mikepenz.markdown.compose.elements.MarkdownHighlightedCodeFence
import com.mikepenz.markdown.compose.elements.MarkdownParagraph
import com.mikepenz.markdown.compose.elements.MarkdownTable
import com.mikepenz.markdown.m3.markdownColor
import com.mikepenz.markdown.m3.markdownTypography
import com.mikepenz.markdown.model.NoOpImageTransformerImpl
import com.mikepenz.markdown.model.StreamingMarkdownState
import com.mikepenz.markdown.utils.resolveImageAlt
import com.mikepenz.markdown.utils.resolveImageLink

/**
 * No-op URI handler: F-01 global defense. Even if a default `linkInteractionListener` survives
 * somewhere in the library's node defaults (headings, lists, quotes, tables — all of which build
 * their annotated text via `annotatorSettings()`'s URI-opening listener per the 0.45.0 sources),
 * `openUri` is a discard. The manifest having no INTERNET permission is NOT a defense: ACTION_VIEW
 * would still launch an external browser, so the handler-level neutralization is the actual
 * boundary.
 */
object NoOpUriHandler : UriHandler {
  override fun openUri(uri: String) {
    // Passive policy: never navigate, never fetch, never launch. (F-01)
  }
}

/**
 * Passive markdown renderer (prototype). Defense in depth, verified against the actual 0.45.0 API:
 * 1. GLOBAL: `LocalUriHandler` is overridden with [NoOpUriHandler] for every node this composable
 *    renders (headings, lists, block quotes, tables, paragraphs);
 * 2. per-node: paragraph and table text are built with `linkInteractionListener = null`, so link
 *    annotations in those nodes carry no click handling at all;
 * 3. images: image/inlineImage components render passive text, plus `NoOpImageTransformerImpl` so
 *    nothing is ever fetched;
 * 4. code fences/blocks render via the `-code` module. No bespoke renderer rewriting and no
 *    per-node wrapper sprawl: the global policy is the primary enforcement, the overrides are
 *    explicit policy documentation.
 */
@Composable
fun PassiveMarkdown(content: String, modifier: Modifier = Modifier) {
  CompositionLocalProvider(LocalUriHandler provides NoOpUriHandler) {
    Markdown(
      content = content,
      colors = markdownColor(),
      typography = markdownTypography(),
      modifier = modifier,
      imageTransformer = NoOpImageTransformerImpl(),
      components = passiveComponents(content),
    )
  }
}

/** Streaming-path variant over a real library `StreamingMarkdownState` (F-06). */
@Composable
fun PassiveStreamingMarkdown(state: StreamingMarkdownState, modifier: Modifier = Modifier) {
  CompositionLocalProvider(LocalUriHandler provides NoOpUriHandler) {
    // Canonical FULL source for AST-offset resolution: the library's own StreamingMarkdownSuccess
    // renders against the accumulated `state.content` (verified 0.45.0 bytecode), whose prefix
    // offsets stay stable within an append generation. Never a paragraph-local slice.
    Markdown(
      streamingMarkdownState = state,
      colors = markdownColor(),
      typography = markdownTypography(),
      modifier = modifier,
      imageTransformer = NoOpImageTransformerImpl(),
      components = passiveComponents(state.content.toString()),
    )
  }
}

private fun passiveComponents(fullSource: String) =
  markdownComponents(
    paragraph = { model ->
      MarkdownParagraph(
        content = model.content,
        node = model.node,
        annotatorSettings = annotatorSettings(linkInteractionListener = null),
      )
    },
    table = { model ->
      MarkdownTable(
        content = model.content,
        node = model.node,
        style = model.typography.text,
        annotatorSettings = annotatorSettings(linkInteractionListener = null),
      )
    },
    image = { model ->
      // Block path: AST offsets are valid against the CANONICAL FULL source (static content or
      // accumulated streaming content — same string the library itself renders against). Alt text
      // is preserved; the URL is the fallback when alt is genuinely absent. Never fetched.
      val link = model.node.resolveImageLink(model.content, null)
      val alt = model.node.resolveImageAlt(fullSource)
      androidx.compose.material3.Text(PassivePolicy.passiveImageText(alt, link))
    },
    inlineImage = { model ->
      // 0.45.0 inline path: buildImageInlineContent already resolves the link and hands it as
      // `model.content` (paragraph-local slice; AST offsets would not match — verified against the
      // 0.45.0 bytecode). The link string is rendered passively, never fetched.
      androidx.compose.material3.Text(PassivePolicy.passiveImageText(null, model.content))
    },
    codeFence = { model ->
      MarkdownHighlightedCodeFence(
        content = model.content,
        node = model.node,
        style = model.typography.code,
      )
    },
    codeBlock = { model ->
      MarkdownHighlightedCodeBlock(
        content = model.content,
        node = model.node,
        style = model.typography.code,
      )
    },
  )
