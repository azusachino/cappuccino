package com.azusachino.cappuccino.prototype.ui

import android.util.Log
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListItemInfo
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.azusachino.cappuccino.prototype.fixture.PiFixtures
import com.azusachino.cappuccino.prototype.logic.FollowPolicy
import com.azusachino.cappuccino.prototype.logic.PassivePolicy
import com.azusachino.cappuccino.prototype.logic.StreamPlayer
import com.azusachino.cappuccino.prototype.logic.WorkspaceState
import com.azusachino.cappuccino.prototype.model.AgentIdentity
import com.azusachino.cappuccino.prototype.model.CompletionTruth
import com.azusachino.cappuccino.prototype.model.MachineGroup
import com.azusachino.cappuccino.prototype.model.Part
import com.azusachino.cappuccino.prototype.model.Role
import com.azusachino.cappuccino.prototype.model.Turn
import com.mikepenz.markdown.model.rememberStreamingMarkdownState
import kotlinx.coroutines.launch

/**
 * BOTH-screen prototype: grouped machine→agent roster + selected workspace. Synthetic fixtures
 * only; unavailable actions render disabled-with-reason; no navigation or fetch.
 */
@OptIn(
  ExperimentalMaterial3Api::class,
  androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
)
@Composable
fun PrototypeApp(
  state: WorkspaceState = WorkspaceState.initial(),
  // Test-only injection point (g journey long-final payload): read at click time; production
  // callers use the default (always null), so the default fixture flow is unchanged.
  longFinalAuthoritative: () -> String? = { null },
) {
  // F-03: the caller-injected state is honored and seeds the mutable screen state.
  var workspace by remember(state) { mutableStateOf(state) }

  // The global app-brand bar DUPLICATES the selected-agent header. While the soft keyboard is up
  // (short profile) it consumed viewport height and clipped the composer text; it collapses only
  // while the IME shows and restores on dismissal. Identity/back/session/status/capability
  // context stays in the per-agent header below.
  val imeVisible = WindowInsets.isImeVisible
  Scaffold(
    topBar = {
      if (!imeVisible) {
        TopAppBar(title = { Text("Cappuccino — prototype (synthetic fixtures)") })
      }
    }
  ) { padding ->
    val selected = workspace.selected
    if (selected == null) {
      RosterScreen(
        PiFixtures.roster,
        onSelect = { workspace = workspace.select(it) },
        modifier = Modifier.padding(padding),
      )
    } else {
      WorkspaceScreen(
        identity = selected,
        state = workspace,
        onBack = { workspace = WorkspaceState(null) },
        longFinalAuthoritative = longFinalAuthoritative,
        modifier = Modifier.padding(padding),
      )
    }
  }
}

@Composable
fun RosterScreen(
  roster: List<MachineGroup>,
  onSelect: (AgentIdentity) -> Unit,
  modifier: Modifier = Modifier,
) {
  LazyColumn(modifier = modifier.fillMaxSize().testTag("roster-list")) {
    roster.forEach { group ->
      item(key = "machine-${group.machine}") {
        Text(
          group.machine,
          style = MaterialTheme.typography.titleSmall,
          modifier = Modifier.padding(12.dp),
        )
        HorizontalDivider()
      }
      group.agents.forEach { row ->
        item(key = row.identity.key) {
          Column(
            modifier =
              Modifier.fillMaxWidth()
                .clickable { onSelect(row.identity) }
                .padding(horizontal = 16.dp, vertical = 10.dp)
          ) {
            Text(
              "${row.identity.name} — ${row.identity.job}",
              style = MaterialTheme.typography.bodyLarge,
            )
            Text("session ${row.identity.sessionId}", style = MaterialTheme.typography.bodySmall)
            Text(
              row.status.label,
              style = MaterialTheme.typography.labelSmall,
              color =
                if (row.status.truth == CompletionTruth.SETTLED) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.tertiary,
            )
          }
        }
      }
    }
  }
}

@OptIn(
  ExperimentalMaterial3Api::class,
  androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
)
@Composable
fun WorkspaceScreen(
  identity: AgentIdentity,
  state: WorkspaceState,
  onBack: () -> Unit,
  modifier: Modifier = Modifier,
  longFinalAuthoritative: () -> String? = { null },
) {
  val row = state.selectedRow(PiFixtures.roster)
  val connectivity = PiFixtures.connectivityFor(identity)
  val turns = PiFixtures.conversationFor(identity)
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()

  // F-02: system back AND a visible back affordance both return to the roster.
  BackHandler(onBack = onBack)

  // Session-scoped state, keyed on identity so nothing leaks across sessions:
  // expansion sets, composer text, streaming player, follow-latest.
  var expandedTools by remember(identity.key) { mutableStateOf(setOf<String>()) }
  var expandedThinking by remember(identity.key) { mutableStateOf(setOf<String>()) }
  var composerText by remember(identity.key) { mutableStateOf("") }
  var player by remember(identity.key) { mutableStateOf(StreamPlayer()) }
  var followLatest by remember(identity.key) { mutableStateOf(true) }
  // Explicit follow-intent marker: absent-tail recovery is armed only after an EXPLICIT chip
  // jump request or the FIRST stream event — never from startup `followLatest = true` alone, so
  // the initial history (first-turn DISPLAYED) is never auto-jumped at composition.
  var tailFollowRequested by remember(identity.key) { mutableStateOf(false) }
  // UI reset epoch: the pure model's reset() returns generation 0 (a genuine generation-0 partial
  // reset leaves the generation unchanged), so rendering state is keyed on (generation, epoch).
  var streamEpoch by remember(identity.key) { mutableIntStateOf(0) }

  // Active programmatic-scroll owners (chip jump, step effect, size convergence). A counter, not
  // a shared boolean: one owner's finally can no longer clear another's still-running guard.
  var programmaticScrollCount by remember { mutableIntStateOf(0) }
  LaunchedEffect(listState) {
    snapshotFlow {
      val info = listState.layoutInfo
      val last = info.visibleItemsInfo.lastOrNull()
      Triple(
        FollowPolicy.isAtActualTail(
          lastIndex = last?.index,
          lastItemEndOffset = last?.let { it.offset + it.size },
          viewportEnd = info.viewportEndOffset,
          total = info.totalItemsCount,
        ),
        listState.isScrollInProgress && programmaticScrollCount == 0,
        programmaticScrollCount,
      )
    }
      .collect { (atTail, userActiveDrag, programmatic) ->
        FollowPolicy.followTransition(atTail, userActiveDrag, programmatic > 0)?.let {
          followLatest = it
        }
      }
  }

  var capabilitiesOpen by remember { mutableStateOf(false) }

  Column(modifier = modifier.fillMaxSize().imePadding()) {
    // Compact native header: identity + truthful status in two small lines (the large card
    // consumed the whole short-profile viewport — see Step C diagnosis PNG). The capability
    // opener lives HERE (bounded header icon), NOT in the crowded control Row below: three
    // unweighted buttons in a finite-width Row starve the third to 0 width and wrap its long
    // text to a huge height, which eats the weighted transcript/composer space.
    Row(
      verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
      modifier =
        Modifier.fillMaxWidth()
          .onGloballyPositioned { Log.i("StepCLayout", "header-row size=${it.size}") }
          .padding(horizontal = 4.dp),
    ) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to roster")
      }
      Column(modifier = Modifier.weight(1f)) {
        Text("${identity.machine} · ${identity.name}", style = MaterialTheme.typography.titleSmall)
        Text(
          "job: ${identity.job} · session: ${identity.sessionId}",
          style = MaterialTheme.typography.bodySmall,
        )
        Text(
          "status: ${row?.status?.label ?: "unknown"}",
          style = MaterialTheme.typography.labelSmall,
        )
        Text(
          if (state.isSettledTruth(row)) "settled truth" else "NOT settled truth",
          style = MaterialTheme.typography.labelSmall,
        )
      }
      IconButton(onClick = { capabilitiesOpen = true }) {
        Icon(
          Icons.Filled.Build,
          contentDescription = "Capabilities: 5 unavailable",
          modifier = Modifier.size(24.dp),
        )
      }
    }

    // Conversation: ordered turns, thinking collapsed by default, tool rows expandable,
    // then the LIVE streaming fixture demo driven through the real library state path.
    LazyColumn(
      state = listState,
      modifier =
        Modifier.weight(1f)
          .fillMaxWidth()
          .testTag("workspace-list")
          .listAnchor(listState) // test-only semantics hook: actual first-visible index+offset
          .onGloballyPositioned { Log.i("StepCLayout", "workspace-list size=${it.size}") },
    ) {
      turns.forEach { turn ->
        turnItems(
          turn,
          expandedTools,
          expandedThinking,
          onToggleTool = { id ->
            expandedTools = if (id in expandedTools) expandedTools - id else expandedTools + id
          },
          onToggleThinking = { id ->
            expandedThinking =
              if (id in expandedThinking) expandedThinking - id else expandedThinking + id
          },
        )
      }
      streamingDemoHeader(player, streamEpoch)
    }

    // Sticky follow affordance: the jump chip LIVES in pinned chrome (always composed, reachable
    // after any drag) — a chip inside the list virtualizes away while reading, leaving the user
    // no way back to the tail. Stock M3 FilterChip; generation truth stays beside it.
    val onJumpLatest: () -> Unit = {
      followLatest = true
      tailFollowRequested = true
      scope.launch {
        programmaticScrollCount++
        try {
          listState.jumpToActualTail()
        } finally {
          programmaticScrollCount-- // cancelled/errored programmatic scroll never sticks
        }
      }
    }
    // IME-adaptive stock-M3 chrome: while the soft keyboard is up (short profile), the DEMO-only
    // follow/control rows collapse so the composer stays positive and above the keys. Identity,
    // back, session/status (header) and capabilities stay reachable; rows restore on dismissal.
    val imeVisible = WindowInsets.isImeVisible
    if (!imeVisible) {
      Row(
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
      ) {
        FilterChip(
          selected = followLatest,
          onClick = onJumpLatest,
          label = { Text("Follow latest") },
        )
        Text(
          "generation ${player.generation} · event ${player.step}/${player.totalSteps}" +
            if (player.finished) " · done" else "",
          style = MaterialTheme.typography.labelSmall,
        )
      }

      // Exactly TWO stream controls, each bounded by weight(1f) — the row can never overflow.
      Row(
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier =
          Modifier.fillMaxWidth()
            .onGloballyPositioned { Log.i("StepCLayout", "control-row size=${it.size}") }
            .padding(horizontal = 8.dp),
      ) {
        OutlinedButton(
          onClick = { player = player.nextOr(longFinalAuthoritative()) },
          enabled = !player.finished,
          modifier = Modifier.weight(1f),
        ) {
          Text("Next stream event", maxLines = 1)
        }
        OutlinedButton(
          onClick = {
            player = player.reset()
            streamEpoch++ // a partial (generation-0) reset must also discard rendering state
          },
          modifier = Modifier.weight(1f),
        ) {
          Text("Reset stream", maxLines = 1)
        }
      }
    }
    if (capabilitiesOpen) {
      ModalBottomSheet(
        onDismissRequest = { capabilitiesOpen = false },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
      ) {
        Column(
          modifier =
            Modifier.fillMaxWidth()
              .verticalScroll(rememberScrollState())
              .testTag("capability-sheet")
              .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text("Unavailable capabilities (synthetic fixture — not backend features)")
          PiFixtures.unavailableActions.forEach { action ->
            AssistChip(
              onClick = {},
              enabled = false,
              label = {
                Column {
                  Text(action.label, style = MaterialTheme.typography.labelMedium)
                  Text(
                    action.reason,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
              },
              modifier = Modifier.disabledReason(action.reason),
            )
          }
        }
      }
    }
    // Decision (followLatest) was captured BEFORE the append that grew the content; the
    // viewport collector above preserved it through growth. Scroll only the actual tail
    // bottom, never index-proximity "near-tail" stealing.
    LaunchedEffect(player.step) {
      if (player.step > 0) {
        tailFollowRequested = true
        if (followLatest && listState.layoutInfo.totalItemsCount > 0) {
          programmaticScrollCount++
          try {
            listState.jumpToActualTail()
          } finally {
            programmaticScrollCount-- // cancelled/errored programmatic scroll never sticks
          }
        }
      }
    }

    // Post-render tail convergence: markdown parsing/layout happens AFTER the step effect samples
    // sizes, so also react to the ACTUAL tail item's layout size growing. At most one jump per
    // observed tail size (finite — the jump changes offset, never size, so it self-terminates);
    // never while a user gesture is in progress, and the effect disarms with followLatest.
    LaunchedEffect(followLatest) {
      if (!followLatest) return@LaunchedEffect
      var handledSize = -1
      // Finite absent-tail recovery: at most one jump per observed absence signature
      // (total:visibleTailIndex) — an identical signature can never re-trigger, so a jump that
      // fails to converge cannot spin.
      var handledAbsence: String? = null
      // The busy/programmatic state is OBSERVED inside the flow: growth dropped while another
      // scroll/animation runs keeps its (unhandled) size and re-fires when the list goes idle —
      // no permanently dropped growth. handledSize bounds it to at most one jump per size.
      snapshotFlow {
        val info = listState.layoutInfo
        val last = info.visibleItemsInfo.lastOrNull()
        val tailSize = if (last != null && last.index == info.totalItemsCount - 1) last.size else -1
        val observation =
          TailObservation(
            tailSize = tailSize,
            atTail =
              FollowPolicy.isAtActualTail(
                lastIndex = last?.index,
                lastItemEndOffset = last?.let { it.offset + it.size },
                viewportEnd = info.viewportEndOffset,
                total = info.totalItemsCount,
              ),
            busy = listState.isScrollInProgress,
            programmatic = programmaticScrollCount,
            lastIndex = last?.index,
            total = info.totalItemsCount,
          )
        observation
      }
        .collect { observation ->
          val (tailSize, atTail, busy, programmatic, lastIndex, total) = observation
          // READ-ONLY fixture diagnostic: an authoritative growth observed while a scroll was
          // still in flight (the drop branch). Never consumed here — handledSize stays unset so
          // the same size re-fires at the idle transition and converges below.
          if (
            tailSize > 0 && tailSize != handledSize && followLatest && (busy || programmatic > 0)
          ) {
            StreamGrowthObserver.lastObservation =
              "growth-during-scroll:size=$tailSize:busy=$busy:programmatic=$programmatic"
          }
          if (followLatest && !busy && programmatic == 0) {
            if (!atTail && tailFollowRequested && total > 0) {
              // Absent-tail recovery (armed by explicit chip/stream request only): late PRE-tail
              // growth or an undershot jump left the tail virtualized away; bring it back once
              // per absence signature. Manual gestures are safe — an active user drag disarms
              // followLatest above, and this branch is idle-only.
              val signature = "$total:${lastIndex}"
              if (signature != handledAbsence) {
                handledAbsence = signature
                programmaticScrollCount++
                try {
                  listState.jumpToActualTail()
                } finally {
                  programmaticScrollCount--
                }
              }
            } else if (atTail) {
              // CLEAN actual-tail convergence: the tail item is present with positive measured
              // size (valid total + positive viewport geometry guard), the list is idle and not
              // programmatically scrolling. Clear the absence signature so a LATER second
              // same-index absence (new late pre-tail growth pushing the tail away again) can
              // recover — while the identical failed-layout signature can never re-fire without
              // first passing through this clean-tail state, so dedup stays finite (no spin).
              handledAbsence = null
            } else if (tailSize > 0 && tailSize != handledSize) {
              handledSize = tailSize
              programmaticScrollCount++
              try {
                listState.jumpToActualTail()
              } finally {
                programmaticScrollCount--
              }
            }
          }
        }
    }

    // Pinned composer (F-04): mutable when connected; explicit disabled states otherwise.
    // Keyed on identity, so text never leaks across sessions. imePadding keeps it above
    // a real soft keyboard (decor-fits-system-windows is false in the activity).
    OutlinedTextField(
      value = composerText,
      onValueChange = { if (state.composerEnabled(connectivity)) composerText = it },
      enabled = state.composerEnabled(connectivity),
      placeholder = { Text(state.composerPlaceholder(connectivity)) },
      // Stock-M3 minimum outlined-field height (56dp): guarantees one full readable glyph line
      // plus label/padding instead of a clipped ~33px sliver (see c4-short-debug PNG).
      modifier =
        Modifier.fillMaxWidth()
          .defaultMinSize(minHeight = 56.dp)
          .onGloballyPositioned { Log.i("StepCLayout", "composer size=${it.size}") }
          .padding(8.dp),
    )
  }
}

private fun LazyListScope.streamingDemoHeader(player: StreamPlayer, streamEpoch: Int) {
  item(key = "stream-header") {
    HorizontalDivider(Modifier.padding(vertical = 8.dp))
    Text(
      "Streaming fixture (message_update-shaped: delta appends, authoritative text_end replacement)",
      style = MaterialTheme.typography.labelMedium,
      modifier = Modifier.padding(horizontal = 16.dp),
    )
  }
  item(key = "stream-body") {
    StreamingDemoBody(
      player = player,
      streamEpoch = streamEpoch,
      // testTag on the NATIVE container (not the library Markdown, which may emit no node while
      // empty/parsing) lets journeys assert the LAST stream BODY is the authoritative tail.
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).testTag("stream-body"),
    )
  }
}

/**
 * F-06: the streaming fixture feeds a REAL library `StreamingMarkdownState`. Reset strategy
 * (0.45.0's state is verified append-only, no replacement API): an authoritative `text_end` event
 * starts a new [StreamPlayer.generation]; keying on the generation discards the old state and seeds
 * a fresh one with the authoritative full text. Deltas within a generation are appended
 * chunk-by-chunk as they arrive.
 */
@Composable
private fun StreamingDemoBody(
  player: StreamPlayer,
  streamEpoch: Int,
  modifier: Modifier = Modifier,
) {
  // (generation, epoch): an authoritative replacement bumps the generation; a reset DURING
  // generation 0 leaves the generation at 0, so the epoch recreates rendering state there too.
  key(player.generation, streamEpoch) {
    val streamState = rememberStreamingMarkdownState()
    var shown by remember { mutableIntStateOf(0) }
    // Keyed on the UI-used chunk count: each restart appends exactly the unseen chunks, once.
    LaunchedEffect(player.chunks.size) {
      while (shown < player.chunks.size) {
        streamState.append(player.chunks[shown])
        shown++
      }
    }
    // Unconditional native M3 body-line minimum on the CONTAINER itself: the library Markdown
    // emits no layout children while the AST parses asynchronously in the background, and
    // `shown` is incremented synchronously with append, so no pending-composition condition can
    // cover that parse window. Only an intrinsic minimum on the Box guarantees the body never
    // collapses to 0px at the Lazy viewport edge (which would dispose the in-flight parser
    // state). No invented geometry: MaterialTheme bodyLarge.lineHeight via LocalDensity.
    val bodyLineHeightDp =
      with(LocalDensity.current) { MaterialTheme.typography.bodyLarge.lineHeight.toDp() }
    var metrics by remember { mutableStateOf("stream-body-metrics:0:0") }
    Box(
      modifier =
        modifier
          .defaultMinSize(minHeight = bodyLineHeightDp)
          // Unclipped layout coordinates (height + bottom-in-root) as semantics — boundsInRoot is
          // clipped and cannot prove tail geometry for a body taller than the viewport.
          .onGloballyPositioned { coords ->
            metrics =
              "stream-body-metrics:${coords.size.height}:${coords.positionInRoot().y + coords.size.height}"
          }
          .semantics { contentDescription = metrics }
    ) {
      if (shown == 0) {
        // Truthful visible empty state; the container above carries the real one-body-line
        // minimum, so this slot is honest status text, not a lifetime guarantee.
        StreamPendingSlot("stream ready — no content yet")
      } else {
        // No `shown < player.chunks.size` pending branch: append increments `shown`
        // synchronously, so that condition is always false here — it was a misleading
        // parser-readiness signal, not a guarantee. Parse-window stability is carried by the
        // unconditional container minimum above.
        PassiveStreamingMarkdown(streamState, modifier = Modifier.fillMaxWidth())
      }
    }
  }
}

/**
 * Native truthful empty-state text line. Lifetime/geometry stability is owned by the container's
 * unconditional M3 `bodyLarge.lineHeight` minimum — this slot is status copy only, never a
 * parser-readiness signal or height guarantee.
 */
@Composable
private fun StreamPendingSlot(label: String) {
  Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.fillMaxWidth())
}

/** Observed viewport tail state for the convergence/recovery collector. */
private data class TailObservation(
  val tailSize: Int,
  val atTail: Boolean,
  val busy: Boolean,
  val programmatic: Int,
  val lastIndex: Int?,
  val total: Int,
)

/**
 * Scroll so the ACTUAL bottom edge of the last item sits at the viewport end — for a long final
 * item `animateScrollToItem(last)` alone aligns its TOP, undershooting.
 */
private suspend fun LazyListState.jumpToActualTail() {
  if (layoutInfo.totalItemsCount == 0) return
  animateScrollToItem(layoutInfo.totalItemsCount - 1)
  val info = layoutInfo
  val last: LazyListItemInfo = info.visibleItemsInfo.lastOrNull() ?: return
  val delta = last.offset + last.size - info.viewportEndOffset + FollowPolicy.TAIL_EPSILON_PX
  if (delta > 0) animateScrollBy(delta.toFloat())
}

/**
 * Test-only READ-ONLY fixture observer: the last authoritative body growth observed by the
 * size-convergence collector while a programmatic scroll was still in flight (i.e. growth that was
 * dropped and must re-fire at idle). Default noop; written only by that collector.
 */
object StreamGrowthObserver {
  @Volatile var lastObservation: String = "growth-during-scroll:none"

  /** Test isolation: scope records to the current run only. */
  fun reset() {
    lastObservation = "growth-during-scroll:none"
  }
}

private fun Modifier.disabledReason(reason: String): Modifier = semantics {
  contentDescription = "disabled: $reason"
}

/** Minimal test-only instrumentation hook: actual viewport anchor (first-visible index + px). */
private fun Modifier.listAnchor(state: LazyListState): Modifier = semantics {
  contentDescription =
    "list-anchor:${state.firstVisibleItemIndex}:${state.firstVisibleItemScrollOffset}"
}

private fun LazyListScope.turnItems(
  turn: Turn,
  expandedTools: Set<String>,
  expandedThinking: Set<String>,
  onToggleTool: (String) -> Unit,
  onToggleThinking: (String) -> Unit,
) {
  item(key = "role-${turn.id}") {
    Text(
      if (turn.role == Role.USER) "You (fixture)" else "Agent (fixture)",
      style = MaterialTheme.typography.labelMedium,
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
    )
  }
  turn.parts.forEachIndexed { index, part ->
    val partId = "${turn.id}-p$index"
    when (part) {
      is Part.Text ->
        item(key = partId) {
          PassiveMarkdown(
            content = part.markdown,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
          )
        }
      is Part.Thinking ->
        item(key = partId) {
          Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
              if (part.redacted) "[redacted thinking — tap to expand label]"
              else "thinking — tap to expand",
              style = MaterialTheme.typography.labelSmall,
              modifier = Modifier.clickable { onToggleThinking(partId) },
            )
            if (partId in expandedThinking) {
              Text(
                PassivePolicy.redactedThoughtLabel(part),
                style = MaterialTheme.typography.bodySmall,
              )
            }
          }
        }
      is Part.ToolCall ->
        item(key = partId) {
          Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            Text(
              (if (part.isError) "⚠ tool error: " else "tool: ") +
                part.name +
                " (tap to " +
                (if (partId in expandedTools) "collapse" else "expand") +
                ")",
              style = MaterialTheme.typography.labelSmall,
              modifier = Modifier.clickable { onToggleTool(partId) },
            )
            if (partId in expandedTools) {
              Text("input: ${part.input}", style = MaterialTheme.typography.bodySmall)
              Text("output: ${part.output}", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
    }
  }
}
