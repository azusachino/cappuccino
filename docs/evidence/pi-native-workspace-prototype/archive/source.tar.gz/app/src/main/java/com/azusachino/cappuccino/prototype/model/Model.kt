package com.azusachino.cappuccino.prototype.model

/**
 * Synthetic Pi-shaped fixture models for the Step B prototype. These mirror the shapes described by
 * Pi's documented content model (`TextContent`, `ThinkingContent` possibly `redacted`, `ToolCall` +
 * tool results) at the level the UI needs. No live protocol, bridge or Pi SDK is used anywhere in
 * this prototype.
 */

/** Completion truth: only [Settled] claims settled; [Heuristic] labels are honest guesses. */
enum class CompletionTruth {
  SETTLED,
  HEURISTIC,
}

enum class AgentStatus(val label: String, val truth: CompletionTruth) {
  SETTLED("settled", CompletionTruth.SETTLED),
  LIKELY_RUNNING("likely running (heuristic)", CompletionTruth.HEURISTIC),
  DISCONNECTED("disconnected", CompletionTruth.HEURISTIC),
}

enum class Connectivity {
  CONNECTED,
  READONLY,
  DISCONNECTED,
}

data class AgentIdentity(
  val machine: String,
  val name: String,
  val job: String,
  val sessionId: String,
) {
  val key: String
    get() = "$machine/$sessionId"
}

data class AgentRow(val identity: AgentIdentity, val status: AgentStatus)

data class MachineGroup(val machine: String, val agents: List<AgentRow>)

sealed interface Part {
  data class Text(val markdown: String) : Part

  /** [redacted] mirrors Pi `ThinkingContent.redacted`; redacted thoughts render a label only. */
  data class Thinking(val content: String, val redacted: Boolean = false) : Part

  data class ToolCall(
    val name: String,
    val input: String,
    val output: String,
    val isError: Boolean = false,
  ) : Part
}

enum class Role {
  USER,
  ASSISTANT,
}

data class Turn(val id: String, val role: Role, val parts: List<Part>)

/** Explicitly unavailable wire capabilities (bridge gaps), rendered disabled-with-reason. */
enum class UnavailableAction(val label: String, val reason: String) {
  QUEUE_STEER("Queue steer", "steer queue intents not on the wire yet"),
  FOLLOW_UP("Follow-up", "follow-up queue intents not on the wire yet"),
  ABORT("Abort", "no abort path implemented"),
  RECEIPTS("Delivery receipts", "receipts not modeled"),
  MODEL_EFFORT_CONTEXT("Model / effort / context", "not exposed by the bridge"),
}
