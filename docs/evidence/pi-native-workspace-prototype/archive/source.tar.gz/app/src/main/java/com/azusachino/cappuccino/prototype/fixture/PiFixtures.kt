package com.azusachino.cappuccino.prototype.fixture

import com.azusachino.cappuccino.prototype.model.AgentIdentity
import com.azusachino.cappuccino.prototype.model.AgentRow
import com.azusachino.cappuccino.prototype.model.AgentStatus
import com.azusachino.cappuccino.prototype.model.Connectivity
import com.azusachino.cappuccino.prototype.model.MachineGroup
import com.azusachino.cappuccino.prototype.model.Part
import com.azusachino.cappuccino.prototype.model.Role
import com.azusachino.cappuccino.prototype.model.Turn
import com.azusachino.cappuccino.prototype.model.UnavailableAction

/**
 * Synthetic Pi-shaped fixtures. Fully invented machines, agent names and session ids — never owner
 * transcripts, addresses or credentials. Clearly labelled prototype data.
 */
object PiFixtures {

  val roster: List<MachineGroup> =
    listOf(
      MachineGroup(
        machine = "harus-mini (fixture)",
        agents =
          listOf(
            AgentRow(
              AgentIdentity(
                "harus-mini (fixture)",
                "mochi",
                "refactor renderer",
                "sess-fixture-0001",
              ),
              AgentStatus.SETTLED,
            ),
            AgentRow(
              AgentIdentity("harus-mini (fixture)", "yuzu", "watch CI", "sess-fixture-0002"),
              AgentStatus.LIKELY_RUNNING,
            ),
          ),
      ),
      MachineGroup(
        machine = "lab-box (fixture)",
        agents =
          listOf(
            AgentRow(
              AgentIdentity("lab-box (fixture)", "anko", "inbox triage", "sess-fixture-0003"),
              AgentStatus.SETTLED,
            ),
            AgentRow(
              AgentIdentity("lab-box (fixture)", "kuri", "backup sweep", "sess-fixture-0004"),
              AgentStatus.DISCONNECTED,
            ),
          ),
      ),
    )

  val defaultSelection: AgentIdentity = roster.first().agents.first().identity

  /** Connectivity per selected session (fixture truth; the composer renders this). */
  fun connectivityFor(identity: AgentIdentity): Connectivity =
    when (identity.name) {
      "kuri" -> Connectivity.DISCONNECTED
      "yuzu" -> Connectivity.READONLY
      else -> Connectivity.CONNECTED
    }

  /**
   * Conversation for a selected agent. Covers: ordered user/assistant turns, thinking (plain +
   * redacted), tool input/output inside the owning turn, long code, and a passive image+link
   * markdown body.
   */
  fun conversationFor(identity: AgentIdentity): List<Turn> =
    listOf(
      Turn(
        id = "${identity.key}-t1",
        role = Role.USER,
        parts = listOf(Part.Text("Summarize the failing test and propose a fix (fixture).")),
      ),
      Turn(
        id = "${identity.key}-t2",
        role = Role.ASSISTANT,
        parts =
          listOf(
            Part.Thinking(
              content =
                "The fixture test redacts thoughts; the parser must keep redacted content out of the body.",
              redacted = false,
            ),
            Part.Thinking(content = "[redacted thinking content]", redacted = true),
            Part.ToolCall(
              name = "read",
              input = """{"path": "app/src/test/kotlin/ExampleTest.kt"}""",
              output = "1: fun test() { assert(fix(false)) }\n2: // 40 more fixture lines follow…",
              isError = false,
            ),
            Part.Text(
              """
              The failing assert is `fix(false)` — the flag was inverted.

              ![fixture image](https://example.invalid/fixture.png)

              Reference: [pi docs](https://example.invalid/docs)
              """
                .trimIndent()
            ),
          ),
      ),
      Turn(
        id = "${identity.key}-t3",
        role = Role.USER,
        parts = listOf(Part.Text("Apply it and show the patch (fixture).")),
      ),
      Turn(
        id = "${identity.key}-t4",
        role = Role.ASSISTANT,
        parts =
          listOf(
            Part.Thinking(content = "[redacted thinking content]", redacted = true),
            Part.ToolCall(
              name = "apply_patch",
              input = """{"file": "Flag.kt", "hunk": "fix(false) -> fix(true)"}""",
              output = "patch applied to 1 file (fixture output)",
              isError = true,
            ),
            Part.Text(longCodeBody()),
          ),
      ),
      Turn(
        id = "${identity.key}-t5",
        role = Role.ASSISTANT,
        parts = listOf(Part.Text(structuredMarkdown())),
      ),
    )

  /** Long code body: renders with the library code module; manual reading + follow-latest. */
  fun longCodeBody(): String = buildString {
    appendLine("Patched (fixture):")
    appendLine()
    appendLine("```kotlin")
    repeat(60) { i -> appendLine("fun fixtureLine_$i(): Int = $i * 2 // padded fixture line $i") }
    appendLine("```")
    appendLine()
    append("End of fixture patch.")
  }

  /**
   * Structured-node fixture: links inside a heading, list items (incl. nested), a block quote and a
   * table. Regression coverage for the F-01 global passivity policy — in 0.45.0 every one of these
   * node types builds link annotations through `annotatorSettings()` defaults, so each must stay
   * un-navigable in the prototype.
   */
  fun structuredMarkdown(): String =
    """
    ## Fixture [heading link](https://example.invalid/heading)

    - item one with a [list link](https://example.invalid/list)
    - item two, plain
      - nested [nested link](https://example.invalid/nested)

    > quoted text with a [quote link](https://example.invalid/quote)

    | col a | col b |
    | ----- | ----- |
    | [table link](https://example.invalid/table) | plain cell |
    """
      .trimIndent()

  /**
   * Streaming fixture shaped per Pi's documented `message_update` events: delta-only appends, then
   * an authoritative full-text replacement at `text_end`.
   */
  object Stream {
    val deltas: List<String> =
      listOf(
        "The fixture ",
        "answer streams **in chunks**",
        " and ends with an authoritative replacement.",
      )

    /** Authoritative full message text delivered with `text_end` (replaces, not appends). */
    val authoritative: String =
      "The fixture answer streams and ends with an authoritative replacement."

    val initial: String
      get() = deltas.first()

    /**
     * Optional structured-authoritative payload (test-only): every structured node type + a REAL
     * image (`![alt](url)`), delivered through the same streaming `text_end` replacement path.
     */
    val structuredAuthoritative: String =
      """
      ## Streaming [stream heading link](https://example.invalid/stream-heading)

      - stream item with a [stream list link](https://example.invalid/stream-list)
        - nested [stream nested link](https://example.invalid/stream-nested)

      > streamed quote with a [stream quote link](https://example.invalid/stream-quote)

      | a | b |
      | - | - |
      | [s table link](https://example.invalid/stream-table) | x |

      ![stream fixture image](https://example.invalid/stream-fixture.png)
      """
        .trimIndent()

    /**
     * Optional g-journey payload: an authoritative replacement whose rendered body is TALLER than
     * the 320x640 short-profile viewport. Default fixture flow and all model tests never read it.
     */
    val longAuthoritative: String = buildString {
      append(authoritative)
      appendLine()
      repeat(80) { i ->
        appendLine("Streaming fixture line $i keeps the final body taller than the viewport.")
      }
    }
  }

  val unavailableActions: List<UnavailableAction> = UnavailableAction.entries.toList()
}
