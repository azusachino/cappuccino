package com.azusachino.cappuccino.prototype.logic

import com.azusachino.cappuccino.prototype.model.Part

/**
 * Passive-media policy, verified against the mikepenz 0.45.0 sources:
 *
 * - Link navigation: `annotatorSettings()`'s DEFAULT `linkInteractionListener` calls
 *   `uriHandler.openUri(...)`. The prototype overrides it with `null` in Compose glue (see
 *   ui/PassiveMarkdown.kt), so links render styled text with no navigation.
 * - Images: the prototype overrides the image/inlineImage components to render `[image:
 *   <alt/link>]` as plain text; the default `NoOpImageTransformerImpl` additionally loads nothing.
 *   Omitting Coil alone would NOT be proof — the component overrides below are the enforcement,
 *   asserted here as policy and by config in the UI.
 */
object PassivePolicy {

  const val LINK_NAVIGATION_DISABLED = true
  const val IMAGES_RENDERED_AS_TEXT = true
  const val NO_REMOTE_FETCH = true

  /** Passive text substitution used by the overridden image components. */
  fun passiveImageText(alt: String?, link: String?): String =
    when {
      !alt.isNullOrBlank() -> "[image: $alt]"
      !link.isNullOrBlank() -> "[image: $link]"
      else -> "[image]"
    }

  /** A redacted thought must never contribute its (nonexistent) content to the body. */
  fun redactedThoughtLabel(part: Part.Thinking): String =
    if (part.redacted) "[redacted thinking content]" else part.content

  /** Tool parts stay inside their owning turn, in list order (asserted by tests). */
  fun orderedParts(turn: List<Part>): List<Part> = turn
}
