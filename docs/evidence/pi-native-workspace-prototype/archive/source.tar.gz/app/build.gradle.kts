import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.compose.compiler)
  alias(libs.plugins.ktfmt)
}

android {
  namespace = "com.azusachino.cappuccino.prototype"
  compileSdk = 37

  defaultConfig {
    // Distinct prototype application id — never installed on a device in Step B.
    applicationId = "com.azusachino.cappuccino.prototype.stepb"
    minSdk = 26
    targetSdk = 37
    versionCode = 1
    versionName = "0.1.0-prototype"
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }
  buildFeatures { compose = true }
  lint {
    warningsAsErrors = true
    abortOnError = true
    disable += "AndroidGradlePluginVersion"
  }
}

kotlin {
  compilerOptions {
    jvmTarget.set(JvmTarget.JVM_17)
    allWarningsAsErrors.set(true)
  }
}

ktfmt { googleStyle() }

dependencies {
  implementation(platform(libs.compose.bom))
  implementation(libs.compose.material3)
  implementation(libs.compose.material.icons.core)
  implementation(libs.activity.compose)
  implementation(libs.lifecycle.runtime.compose)
  implementation(libs.coroutines.android)
  // Prototype-only renderer candidates (proof-of-fit; no production adoption).
  implementation(libs.mikepenz.markdown.m3)
  implementation(libs.mikepenz.markdown.code)
  testImplementation(libs.junit)
  testImplementation(libs.coroutines.test)
  androidTestImplementation(platform(libs.compose.bom))
  androidTestImplementation(libs.compose.ui.test)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.test.runner)
  debugImplementation(libs.compose.ui.test.manifest)
}
