import org.jetbrains.kotlin.gradle.dsl.JvmTarget

buildscript {
  dependencies {
    // Align AGP's built-in Kotlin with the Compose compiler without the legacy Android plugin.
    classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:${libs.versions.kotlin.get()}")
  }
}

plugins {
  alias(libs.plugins.android.application) apply false
  alias(libs.plugins.compose.compiler) apply false
  alias(libs.plugins.ktfmt) apply false
}
